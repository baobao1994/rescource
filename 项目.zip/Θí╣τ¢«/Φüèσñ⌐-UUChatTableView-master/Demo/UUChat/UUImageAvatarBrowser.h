//
//  UUAVAudioPlayer.h
//  BloodSugarForDoc
//
//  Created by shake on 14-9-1.
//  Copyright (c) 2014年 shake. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UUImageAvatarBrowser : NSObject

//show imageView on the keyWindow
+(void)showImage:(UIImageView*)avatarImageView;

@end
