//
//  ViewController.m
//  Runaround
//
//  Created by 郭伟文 on 16/6/12.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "ViewController.h"



@interface ViewController ()<UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *hahaLabel;
@property (strong, nonatomic) UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIView *backView;
@property (assign, nonatomic) float lastPositionX;
@property (assign, nonatomic) float lastPositionY;
@property (assign, nonatomic) BOOL isEndScroll;

@property (copy, nonatomic) UILabel *labelOne;
@property (copy, nonatomic) UILabel *labelTwo;
@property (copy, nonatomic) UILabel *labelThree;
@property (copy, nonatomic) UILabel *labelFour;
@property (copy, nonatomic) UILabel *labelFive;
@property (copy, nonatomic) UILabel *labelSix;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.backView.frame.size.width , self.backView.frame.size.width)];
    scrollView.contentSize = CGSizeMake(self.view.bounds.size.height, self.view.bounds.size.height);
    scrollView.delegate = self;
    scrollView.bounces = NO;
    scrollView.contentOffset = CGPointMake(self.view.bounds.size.height/3, self.view.bounds.size.height/3);//设置中心
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.alwaysBounceVertical = YES;
    scrollView.alwaysBounceHorizontal = YES;
    scrollView.backgroundColor = [UIColor yellowColor];
    [self.backView addSubview:scrollView];
    self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 150, 150)];
    self.imageView.center = self.backView.center;
    self.imageView.image = [UIImage imageNamed:@"六边形4.png"];
    [self.view addSubview:self.imageView];
    [self.view bringSubviewToFront:self.imageView];
    //文字label
    _labelOne = [[UILabel alloc] initWithFrame:CGRectMake(self.imageView.center.x - 15, self.imageView.center.y - 75-20, 30, 20)];
    _labelOne.textAlignment = NSTextAlignmentCenter;
    _labelOne.text = @"英超";
    _labelOne.font = [UIFont systemFontOfSize:12.0f];
    _labelOne.backgroundColor = [UIColor redColor];
    [self.view addSubview:_labelOne];
    
    _labelTwo = [[UILabel alloc] initWithFrame:CGRectMake(self.imageView.center.x +  sqrt(pow(75, 2) - pow(75/2.0, 2)), self.imageView.center.y - 75/2.0 - 10, 30, 20)];
    _labelTwo.textAlignment = NSTextAlignmentCenter;
    _labelTwo.text = @"西甲";
    _labelTwo.font = [UIFont systemFontOfSize:12.0f];
    _labelTwo.backgroundColor = [UIColor redColor];
    [self.view addSubview:_labelTwo];
    
    _labelThree = [[UILabel alloc] initWithFrame:CGRectMake(self.imageView.center.x +  sqrt(pow(75, 2) - pow(75/2.0, 2)), self.imageView.center.y + 75/2.0 - 10, 30, 20)];
    _labelThree.textAlignment = NSTextAlignmentCenter;
    _labelThree.text = @"法甲";
    _labelThree.font = [UIFont systemFontOfSize:12.0f];
    _labelThree.backgroundColor = [UIColor redColor];
    [self.view addSubview:_labelThree];

    _labelFour = [[UILabel alloc] initWithFrame:CGRectMake(self.imageView.center.x - 15, self.imageView.center.y + 75, 30, 20)];
    _labelFour.textAlignment = NSTextAlignmentCenter;
    _labelFour.text = @"德甲";
    _labelFour.font = [UIFont systemFontOfSize:12.0f];
    _labelFour.backgroundColor = [UIColor redColor];
    [self.view addSubview:_labelFour];

    _labelFive = [[UILabel alloc] initWithFrame:CGRectMake(self.imageView.center.x -  sqrt(pow(75, 2) - pow(75/2.0, 2)) - 30, self.imageView.center.y + 75/2.0 - 10, 30, 20)];
    _labelFive.textAlignment = NSTextAlignmentCenter;
    _labelFive.text = @"意甲";
    _labelFive.font = [UIFont systemFontOfSize:12.0f];
    _labelFive.backgroundColor = [UIColor redColor];
    [self.view addSubview:_labelFive];
    
    _labelSix = [[UILabel alloc] initWithFrame:CGRectMake(self.imageView.center.x -  sqrt(pow(75, 2) - pow(75/2.0, 2)) - 30, self.imageView.center.y - 75/2.0 - 10, 30, 20)];
    _labelSix.textAlignment = NSTextAlignmentCenter;
    _labelSix.text = @"其它";
    _labelSix.font = [UIFont systemFontOfSize:12.0f];
    _labelSix.backgroundColor = [UIColor redColor];
    [self.view addSubview:_labelSix];
    
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {//时刻监听滑动
    NSLog(@"Did Scroll");
    float offSetX = scrollView.contentOffset.x;
    float offSetY = scrollView.contentOffset.y;
    if (fabsf(offSetY - _lastPositionY) > 5) {
        _lastPositionY = offSetY;
        self.imageView.transform = CGAffineTransformMakeRotation(-offSetY*(M_PI*4/9)/150); //垂直滑动
    }else if (fabsf(offSetX - _lastPositionX) > 5) {
        _lastPositionX = offSetX;
        self.imageView.transform = CGAffineTransformMakeRotation(offSetX*(M_PI*4/9)/150); //水平滑动
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {//开始滑动
    NSLog(@"Will BeginDragging");
}

-(void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView {//快速滑动开始
    CGPoint offset = scrollView.contentOffset;
//    [scrollView setContentOffset:offset animated:NO];
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {//快速滑动结束
    NSLog(@"End Decelerating");
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {//滑动结束
    NSLog(@"End Scrolling2");
    _isEndScroll = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
