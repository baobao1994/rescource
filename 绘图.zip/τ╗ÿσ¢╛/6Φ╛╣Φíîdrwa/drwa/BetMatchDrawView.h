//
//  sixsix.h
//  drwa
//
//  Created by 郭伟文 on 16/7/21.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BetMatchDrawView : UIView

@property (nonatomic,strong) NSDictionary *betMatchStatisDic;

@end

