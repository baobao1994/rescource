//
//  sixsix.m
//  drwa
//
//  Created by 郭伟文 on 16/7/21.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "BetMatchDrawView.h"

#define kWidth [UIScreen mainScreen].bounds.size.width
#define KCenterY 80   //图形的中点Y轴高度(高度为160)
#define kTextWidth 20 //文字的宽度
#define kTextHight 10 //文字的高度
#define KSpace      5 //文字与图形间隙
#define BEPL       @"bepl" //英超
#define EPL        @"epl"  //西甲
#define LFP        @"lfp"  //法甲
#define BL         @"bl"   //德甲
#define SLA        @"sla"  //意甲
#define OTHER      @"other"//其它

@interface BetMatchDrawView()

@property (nonatomic,assign) NSUInteger bepl;
@property (nonatomic,assign) NSUInteger epl;
@property (nonatomic,assign) NSUInteger lfp;
@property (nonatomic,assign) NSUInteger bl;
@property (nonatomic,assign) NSUInteger sla;
@property (nonatomic,assign) NSUInteger other;
@property (nonatomic,assign) float allNum;

@end

@implementation BetMatchDrawView

- (void)drawRect:(CGRect)rect {
    self.betMatchStatisDic = [NSDictionary dictionaryWithObjectsAndKeys:@85,@"bepl",@41,@"bl",@77,@"epl",@26,@"lfp",@61,@"sla",@1325,@"other", nil];
    self.bepl = [[self.betMatchStatisDic valueForKey:BEPL] integerValue];
    self.epl = [[self.betMatchStatisDic valueForKey:EPL] integerValue];
    self.lfp = [[self.betMatchStatisDic valueForKey:LFP] integerValue];
    self.bl = [[self.betMatchStatisDic valueForKey:BL] integerValue];
    self.sla = [[self.betMatchStatisDic valueForKey:SLA] integerValue];
    self.other = [[self.betMatchStatisDic valueForKey:OTHER] integerValue];
    self.allNum = self.bepl + self.epl + self.lfp + self.bl + self.sla + self.other * 1.0;
    //大背景
    UIBezierPath* rectanglePath = [UIBezierPath bezierPathWithRect: CGRectMake(0, 0, kWidth, 160)];
    [UIColor.whiteColor setFill];
    [rectanglePath fill];
    //最外层的六边形
    // A:X轴
    // B:Y轴
    // R:半径 每个环中间间隔15
    // R2:连线固定Max半径
    int A = kWidth / 2, B = 20, R = 60, R2 = 55;
    float Rdif = 0;
    ///SixPointView
    UIBezierPath* bezierPath = [UIBezierPath bezierPath];
    Rdif = R2 - R2 * self.bepl / self.allNum;
    [bezierPath moveToPoint: CGPointMake(A, KCenterY - Rdif)];
    
    Rdif = R2 - R2 * self.epl / self.allNum;
    [bezierPath addLineToPoint: CGPointMake(A - Rdif * sqrtf(3.0) / 2, KCenterY - Rdif / 2)];
    Rdif = R2 - R2 * self.lfp / self.allNum;
    [bezierPath addLineToPoint: CGPointMake(A - Rdif * sqrtf(3.0) / 2, KCenterY + Rdif / 2)];
    
    Rdif = R2 - R2 * self.bl / self.allNum;
    [bezierPath addLineToPoint: CGPointMake(A, KCenterY + Rdif)];
    
    Rdif = R2 - R2 * self.sla / self.allNum;
    [bezierPath addLineToPoint: CGPointMake(A + Rdif * sqrtf(3.0) / 2, KCenterY + Rdif / 2)];
    Rdif = R2 - R2 * self.other / self.allNum;
    [bezierPath addLineToPoint: CGPointMake(A + Rdif * sqrtf(3.0) / 2, KCenterY - Rdif / 2)];
    
    Rdif = R2 - R2 * self.bepl / self.allNum;
    [bezierPath addLineToPoint: CGPointMake(A, KCenterY - Rdif)];
    [bezierPath closePath];
    [[UIColor colorWithRed:211/255.0f green:134/255.0f blue:134/255.0f alpha:1] setFill];
    [bezierPath fill];
    [[UIColor redColor] setStroke];
    bezierPath.lineWidth = 1;
    [bezierPath stroke];
    for (int i = 0; i < 5; i ++) {
        NSMutableArray *rPointAarr = [[NSMutableArray alloc] init];
        NSMutableArray *rPointBarr = [[NSMutableArray alloc] init];
        UIBezierPath *bezierPath = [UIBezierPath bezierPath];
        [bezierPath moveToPoint: CGPointMake(A, B)];//F1
        [rPointAarr addObject:@(A - kTextWidth/2)];
        [rPointBarr addObject:@(B - kTextHight - KSpace)];
        
        [bezierPath addLineToPoint: CGPointMake(A - R * sqrtf(3.0) / 2.0, B + R / 2.0)];//F2
        [rPointAarr addObject:@(A - R * sqrtf(3.0) / 2.0 - kTextWidth - 3)];
        [rPointBarr addObject:@(B + R / 2.0 - kTextHight / 2 - KSpace)];
        
        [bezierPath addLineToPoint: CGPointMake(A - R * sqrtf(3.0) / 2.0, B + R / 2.0 + R)];//F3
        [rPointAarr addObject:@(A - R * sqrtf(3.0) / 2.0 - kTextWidth - 3)];
        [rPointBarr addObject:@(B + R / 2.0 + R - kTextHight / 2  + KSpace)];
        
        [bezierPath addLineToPoint: CGPointMake(A, B + 2 * R)];//F4
        [rPointAarr addObject:@(A - kTextWidth/2)];
        [rPointBarr addObject:@(B + 2 * R + KSpace)];
        
        [bezierPath addLineToPoint: CGPointMake(A + R * sqrtf(3.0) / 2.0, B + R / 2.0 + R)];//F5
        [rPointAarr addObject:@(A + R * sqrtf(3.0) / 2.0 + KSpace)];
        [rPointBarr addObject:@(B + R / 2.0 + R - kTextHight / 2 + KSpace)];
        
        [bezierPath addLineToPoint: CGPointMake(A + R * sqrtf(3.0) / 2.0, B + R / 2.0)];//F6
        [rPointAarr addObject:@(A + R * sqrtf(3.0) / 2.0 + KSpace)];
        [rPointBarr addObject:@(B + R / 2.0 - kTextHight / 2 - KSpace)];
        
        [bezierPath addLineToPoint: CGPointMake(A, B)];//F1
        [bezierPath closePath];
        [[UIColor colorWithRed:204/255.0f green:204/255.0f blue:204/255.0f alpha:1] setStroke];
        bezierPath.lineWidth = 1;
        [bezierPath stroke];
        if (i == 0) {
            //连线
            UIBezierPath *bezierPath2 = [UIBezierPath bezierPath];
            [bezierPath2 moveToPoint: CGPointMake(A, B)];//F1
            [bezierPath2 addLineToPoint: CGPointMake(A, B + 2 * R)];//F4
            [bezierPath2 closePath];
            [[UIColor colorWithRed:204/255.0f green:204/255.0f blue:204/255.0f alpha:1] setStroke];
            bezierPath2.lineWidth = 1;
            [bezierPath2 stroke];
            
            UIBezierPath *bezierPath3 = [UIBezierPath bezierPath];
            [bezierPath3 moveToPoint: CGPointMake(A - R * sqrtf(3.0) / 2.0, B + R / 2.0)];//F2
            [bezierPath3 addLineToPoint: CGPointMake(A + R * sqrtf(3.0) / 2.0, B + R / 2.0 + R)];//F5
            [bezierPath3 closePath];
            [[UIColor colorWithRed:204/255.0f green:204/255.0f blue:204/255.0f alpha:1] setStroke];
            bezierPath3.lineWidth = 1;
            [bezierPath3 stroke];
            
            UIBezierPath *bezierPath4 = [UIBezierPath bezierPath];
            [bezierPath4 moveToPoint: CGPointMake(A - R * sqrtf(3.0) / 2.0, B + R / 2.0 + R)];//F3
            [bezierPath4 addLineToPoint: CGPointMake(A + R * sqrtf(3.0) / 2.0, B + R / 2.0)];//F6
            [bezierPath4 closePath];
            [[UIColor colorWithRed:204/255.0f green:204/255.0f blue:204/255.0f alpha:1] setStroke];
            bezierPath4.lineWidth = 1;
            [bezierPath4 stroke];
            /// Text Drawing
            NSArray *namaArr = [NSArray arrayWithObjects:@"法甲",@"其他",@"西甲",@"德甲",@"意甲",@"英超", nil];
            for (int j = 0; j < 6 ; j ++) {
                CGContextRef context = UIGraphicsGetCurrentContext();
                CGRect SQtextRect = CGRectMake([rPointAarr[j] intValue], [rPointBarr[j] intValue], kTextWidth, kTextHight);
                NSString* textContent = namaArr[j];
                NSMutableParagraphStyle* textStyle = NSMutableParagraphStyle.defaultParagraphStyle.mutableCopy;
                textStyle.alignment = NSTextAlignmentCenter;
                
                NSDictionary* textFontAttributes = @{NSFontAttributeName: [UIFont systemFontOfSize: 10], NSForegroundColorAttributeName: UIColor.blackColor, NSParagraphStyleAttributeName: textStyle};
                
                CGFloat textTextHeight = [textContent boundingRectWithSize: CGSizeMake(SQtextRect.size.width, INFINITY)  options: NSStringDrawingUsesLineFragmentOrigin attributes: textFontAttributes context: nil].size.height;
                CGContextSaveGState(context);
                CGContextClipToRect(context, SQtextRect);
                [textContent drawInRect: CGRectMake(CGRectGetMinX(SQtextRect), CGRectGetMinY(SQtextRect) + (CGRectGetHeight(SQtextRect) - textTextHeight) / 2, CGRectGetWidth(SQtextRect), textTextHeight) withAttributes: textFontAttributes];
                CGContextRestoreGState(context);
            }
        }
        R -= 15;
        B += 15;
    }
    
}

@end
