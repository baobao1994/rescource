//
//  ViewController.m
//  drwa
//
//  Created by 郭伟文 on 16/7/21.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "ViewController.h"
#import "BetMatchDrawView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    BetMatchDrawView *sixView = [[BetMatchDrawView alloc] init];
    sixView.backgroundColor = [UIColor whiteColor];
    sixView.frame = CGRectMake(0, 100, [UIScreen mainScreen].bounds.size.width, 160);
    [self.view addSubview:sixView];
}


@end
