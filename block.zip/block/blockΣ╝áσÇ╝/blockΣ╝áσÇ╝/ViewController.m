//
//  ViewController.m
//  block传值
//
//  Created by baobao on 16/3/22.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"
#import "second.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //无参数无返回值
    void(^printBlock)() = ^(){
        NSLog(@"no number");
    };
    printBlock();
    printBlock(9);
    
    int mutiplier = 7;
    //定义myblock代码块,返回值是int类型
    int(^myBlock)(int) = ^(int num){
        return num * mutiplier;
    };
    int new = myBlock(3);
    NSLog(@"%d",new);
    
    
    //有参数 没有返回值
    void(^numBlock)(int) = ^(int num){
        NSLog(@"numBlock=%d",num);
    };
    numBlock(3);
    
    //修改外部变量(block 关键字的使用)
    __block int x = 100;
    void(^sumXWithYBlock)(int) = ^(int y){
        x = x + y;
        NSLog(@"new value %d",x);
    };
    sumXWithYBlock(100);

    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn:(UIButton *)sender {
    second *ss = [[second alloc] init];
    [ss returnText:^(NSString *showText) {
        self.lable.text = showText;
    }];
    [self.navigationController pushViewController:ss animated:YES];
}
@end
