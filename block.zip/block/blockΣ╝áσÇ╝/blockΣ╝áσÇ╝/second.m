//
//  second.m
//  block传值
//
//  Created by baobao on 16/3/22.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "second.h"

@interface second ()

@property (weak, nonatomic) IBOutlet UITextField *lable;
@end

@implementation second

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)returnText:(ReturnTextBlock)block{
    self.returnTextBlock = block;
}

- (void)viewWillDisappear:(BOOL)animated{
    if (self.returnTextBlock != nil) {
        self.returnTextBlock(self.lable.text);
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
