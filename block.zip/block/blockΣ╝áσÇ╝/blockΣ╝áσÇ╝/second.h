//
//  second.h
//  block传值
//
//  Created by baobao on 16/3/22.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^ReturnTextBlock)(NSString *showText);

@interface second : UIViewController

@property (nonatomic,copy) ReturnTextBlock returnTextBlock;

-(void)returnText:(ReturnTextBlock)block;

@end
