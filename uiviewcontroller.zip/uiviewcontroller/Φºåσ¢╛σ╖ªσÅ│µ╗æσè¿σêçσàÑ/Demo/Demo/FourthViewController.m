//
//  FourthViewController.m
//  Demo
//
//  Created by Andrea Mazzini on 01/05/14.
//  Copyright (c) 2014 Fancy Pixel. All rights reserved.
//

#import "FourthViewController.h"

@interface FourthViewController ()

@end

@implementation FourthViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor clearColor]];
}

@end
