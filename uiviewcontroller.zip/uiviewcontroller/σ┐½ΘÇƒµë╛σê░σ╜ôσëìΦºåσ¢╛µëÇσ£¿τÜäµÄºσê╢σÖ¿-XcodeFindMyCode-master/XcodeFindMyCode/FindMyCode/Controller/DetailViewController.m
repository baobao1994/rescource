//
//  DetailViewController.m
//  FindMyCodeDemo
//
//  Created by 张小刚 on 16/3/5.
//  Copyright © 2016年 lyeah company. All rights reserved.
//

#import "DetailViewController.h"
#import "CViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Detail";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)pushC:(id)sender {
    CViewController *CVC = [[CViewController alloc] init];
    CVC.title = @"cccc";
    [self.navigationController pushViewController:CVC animated:YES];
}
@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com