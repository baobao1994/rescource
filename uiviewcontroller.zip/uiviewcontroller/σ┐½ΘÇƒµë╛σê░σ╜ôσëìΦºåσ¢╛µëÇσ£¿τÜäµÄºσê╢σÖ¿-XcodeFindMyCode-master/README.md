# XcodeFindMyCode
Long press your viewcontroller\`s view, Xcode will open that controller\`s source file.

It contains two components: some code for iOS, and a plugin for Xcode.

---
**usage**:

- for iOS client, copy the content in /product/XcodeFinMyCode directory to your iOS project.
- for Xcode client, copy the plugin /product/XcodeFindMyCode.xcplugin to your plugin directory(~/Library/Application Support/Developer/Shared/Xcode/Plug-ins)

[video demo][1]


 

[1]: http://www.miaopai.com/show/YUduW4PFx6SYsEeekRy~AQ__.htm
