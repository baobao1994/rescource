//
//  RightViewController.h
//  WYApp
//
//  Created by chen on 14-7-17.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightViewController : UIViewController

//可以旋转的UIImage
@property (nonatomic,retain) UIImageView *headImageView;

- (void)headPhotoAnimation;

@end
