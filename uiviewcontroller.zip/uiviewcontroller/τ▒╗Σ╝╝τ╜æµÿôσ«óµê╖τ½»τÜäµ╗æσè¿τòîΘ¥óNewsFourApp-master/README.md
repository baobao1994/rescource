NewsFourApp
===========

高仿网易4.0新UI框架的Demo

声明：如果有好的修改，非常欢迎fork提交分享哈

注意：（建议将MLTransition换[MLBlackTransition](https://github.com/molon/MLTransition)，

因为此修复bug，如：使用UIImagePickerController获取图片）

![image](https://github.com/chenqihui/NewsFourApp/blob/master/screenshots/NewsFourAppGif.gif)

---------------------------华丽丽的分割线------------------------------

beta 0.2

---------------------------华丽丽的分割线------------------------------

beta 0.1

1、新的抽屉效果，修改于SliderViewController，不过里面已经不一样，毕竟是新的效果嘛
(此部分还不算完全具备框架的特性，呵呵😄)

2、首页滑动导航菜单的字体大小和颜色，随scrollView滑动的变化而变化的效果

3、使用MLTransition的返回功能和LBBlurredImage实现毛玻璃效果
（建议将MLTransition换[MLBlackTransition](https://github.com/molon/MLTransition)）

4、各种跳转的调用

5、根据NewsTwoApp的建议来修改部分bug及实现需求

6、增加显示右边view之后的回调方法

---------------------------------------------------------------------
