//
//  HXViewController.h
//  HXSuperLabel
//
//  Created by 黄轩 on 16/1/14.
//  Copyright © 2016年 IT小子. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HXViewController : UIViewController


@end

