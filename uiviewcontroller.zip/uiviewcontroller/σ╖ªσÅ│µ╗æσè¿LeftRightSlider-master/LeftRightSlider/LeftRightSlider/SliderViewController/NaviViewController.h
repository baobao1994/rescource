//
//  NaviViewController.h
//  LeftRightSlider
//
//  Created by jimple on 14-5-8.
//  Copyright (c) 2014年 heroims. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NaviViewController : UINavigationController

@end
