//
//  ViewController2.h
//  LeftRightSlider
//
//  Created by Zhao Yiqi on 13-11-29.
//  Copyright (c) 2013年 heroims. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SliderContentViewController.h"

@interface ViewController2 : SliderContentViewController

@end
