//
//  ViewController.m
//  scrollview
//
//  Created by baobao on 15/10/20.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    UIImageView *imageView = [[UIImageView alloc]init];
//    imageView.image = [UIImage imageNamed:@"liverpool-2.jpg"];
//    imageView.frame = self.view.bounds;//等于整个父的view的整个屏幕的外观，会被扭曲
//    CGFloat height= imageView.image.size.height;//生成一个没有扭曲的图片，但是无法完全显示在窗口中
//    CGFloat width = imageView.image.size.width;
//    imageView.frame = CGRectMake(0, 0, width, height);
    UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"liverpool-2.jpg"]];
    [self.view addSubview:imageView];
    UIScrollView *scroView = [[UIScrollView alloc]init];
    scroView.frame = CGRectMake(0, 20, 320, 548);
    scroView.backgroundColor = [UIColor grayColor];
    [scroView addSubview:imageView];
    //scrollview的内容区域大小
    scroView.contentSize = imageView.frame.size;
    //关闭右边的滚动条和下面的滚动条
    scroView.showsHorizontalScrollIndicator = NO;
    scroView.showsVerticalScrollIndicator = NO;
    //设置溢出区的范围,弹跳效果
    scroView.bounces = NO;
    //增加一个溢出区,相当于padding
    scroView.contentInset = UIEdgeInsetsMake(20, 20, 20, 20);
    //偏移量，就是先指定我需要的地方当做主页面的显示eg:指向100，100的位置
    scroView.contentOffset = CGPointMake(100, 100);
    //
    [self.view addSubview:scroView];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
