//
//  _____________Tests.m
//  类似网易新闻的顶部滑动效果Tests
//
//  Created by 郭伟文 on 16/8/16.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _____________Tests : XCTestCase

@end

@implementation _____________Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
