//
//  NSString+Addition.h
//  TigerLottery
//
//  Created by Legolas on 14/12/9.
//  Copyright (c) 2014年 adcocoa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface NSString (Addition)

- (CGSize)adaptSizeWithFont:(UIFont *)font;
- (CGSize)adaptSizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size;

@end
