//
//  ViewController.m
//  类似网易新闻的顶部滑动效果
//
//  Created by 郭伟文 on 16/8/16.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "ViewController.h"
#import "SXTitleLable.h"
#import "SXTableViewController.h"
#import "NSString+Addition.h"

@interface ViewController ()<UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UIScrollView *smallScrollView;
@property (weak, nonatomic) IBOutlet UIScrollView *bigScrollView;

@property(nonatomic,strong) SXTitleLable *oldTitleLable;
@property (nonatomic,assign) CGFloat beginOffsetX;
@property(nonatomic,strong) NSArray *arrayLists;

@end

@implementation ViewController

#pragma mark - ******************** 懒加载
- (NSArray *)arrayLists {
    if (_arrayLists == nil) {
        _arrayLists = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"NewsURLs.plist" ofType:nil]];
    }
    return _arrayLists;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.smallScrollView.showsHorizontalScrollIndicator = NO;
    self.smallScrollView.showsVerticalScrollIndicator = NO;
    self.bigScrollView.delegate = self;
    [self addController];
    [self addLable];
    CGFloat contentX = self.childViewControllers.count * [UIScreen mainScreen].bounds.size.width;
    self.bigScrollView.contentSize = CGSizeMake(contentX, 0);
    self.bigScrollView.pagingEnabled = YES;
    SXTitleLable *sxTitle = [self.smallScrollView.subviews firstObject];
    sxTitle.scale = 1.0;
    SXTitleLable *sxTitleLine = [self.smallScrollView.subviews objectAtIndex:1];
    sxTitleLine.scale = 1.0;
    self.bigScrollView.showsHorizontalScrollIndicator = NO;
}

/** 添加子控制器 */
- (void)addController {
    for (int i=0 ; i<self.arrayLists.count ;i++){
        SXTableViewController *vc = [[SXTableViewController alloc] init];
        vc.title = self.arrayLists[i][@"title"];
        vc.view.frame = CGRectMake(0 + [UIScreen mainScreen].bounds.size.width *i, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 104);
        [self.bigScrollView addSubview:vc.view];
        [self addChildViewController:vc];
    }
}

/** 添加标题栏 */
- (void)addLable {
    for (int i = 0; i < 8; i++) {
        CGFloat lblW = 70;
        CGFloat lblH = 36;
        CGFloat lblY = 0;
        CGFloat lblX = i * lblW;
        SXTitleLable *lbl1 = [[SXTitleLable alloc]init];
        UIViewController *vc = self.childViewControllers[i];
        CGSize lblSize = [vc.title adaptSizeWithFont:[UIFont systemFontOfSize:18.0f]];
        lbl1.text =vc.title;
        lbl1.textAlignment = NSTextAlignmentCenter;
        lbl1.frame = CGRectMake(lblX, lblY, lblW, lblH);
        lbl1.font = [UIFont systemFontOfSize:18.0f];
        [self.smallScrollView addSubview:lbl1];
        lbl1.tag = i;
        lbl1.userInteractionEnabled = YES;
        [lbl1 addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(lblClick:)]];
        SXTitleLable *sxTitleLine = [[SXTitleLable alloc] initWithFrame:CGRectMake((lblW - lblSize.width)/ 2 + lblX, lblH + 2, lblSize.width, 2)];
        sxTitleLine.backgroundColor = [UIColor redColor];
        [self.smallScrollView addSubview:sxTitleLine];
    }
    self.smallScrollView.contentSize = CGSizeMake(70 * 8, 0);
}

/** 标题栏label的点击事件 */
- (void)lblClick:(UITapGestureRecognizer *)recognizer {
    SXTitleLable *titlelable = (SXTitleLable *)recognizer.view;
    CGFloat offsetX = titlelable.tag * self.bigScrollView.frame.size.width;
    CGFloat offsetY = self.bigScrollView.contentOffset.y;
    CGPoint offset = CGPointMake(offsetX, offsetY);
    [self.bigScrollView setContentOffset:offset animated:YES];//快速滑动--有动画
    
    //没有动画直接一闪而过
//    [self.bigScrollView setContentOffset:offset animated:NO];
//    [self scrollViewDidScroll:self.bigScrollView];
//    [self scrollViewDidEndScrollingAnimation:self.bigScrollView];
}

#pragma mark - ******************** scrollView代理方法

/** 滚动结束后调用（代码导致） */
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    // 获得索引
    NSUInteger index = scrollView.contentOffset.x / self.bigScrollView.frame.size.width / 2 * 2;
    // 滚动标题栏
    SXTitleLable *titleLable = (SXTitleLable *)self.smallScrollView.subviews[index  * 2];
    
    CGFloat offsetx = titleLable.center.x - self.smallScrollView.frame.size.width * 0.5;
    
    CGFloat offsetMax = self.smallScrollView.contentSize.width - self.smallScrollView.frame.size.width;
    if (offsetx < 0) {
        offsetx = 0;
    }else if (offsetx > offsetMax){
        offsetx = offsetMax;
    }
    
    CGPoint offset = CGPointMake(offsetx, self.smallScrollView.contentOffset.y);
    [self.smallScrollView setContentOffset:offset animated:YES];
    // 添加控制器
    SXTableViewController *newsVc = self.childViewControllers[index];
    newsVc.index = index;
    
    [self.smallScrollView.subviews enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        if ((idx / 2) != index) {
            SXTitleLable *sxTitle = self.smallScrollView.subviews[idx / 2 * 2];
            sxTitle.scale = 0.0;
            SXTitleLable *sxTitleLine = self.smallScrollView.subviews[idx / 2 * 2 + 1];
            sxTitleLine.scale = 0.0;
        }
    }];
    
    if (newsVc.view.superview) return;
    
    newsVc.view.frame = scrollView.bounds;
    [self.bigScrollView addSubview:newsVc.view];
}

/** 滚动结束（手势导致） */
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    [self scrollViewDidEndScrollingAnimation:scrollView];
}

/** 正在滚动 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    // 取出绝对值 避免最左边往右拉时形变超过1
    CGFloat value = ABS(scrollView.contentOffset.x / scrollView.frame.size.width);
    // 获得索引
    NSUInteger index = scrollView.contentOffset.x / self.bigScrollView.frame.size.width / 2 * 2;
    NSUInteger leftIndex = (int)value;
    NSUInteger rightIndex = leftIndex + 1;
    CGFloat scaleRight = value - leftIndex;
    CGFloat scaleLeft = 1 - scaleRight;
    
    SXTitleLable *labelLeft = self.smallScrollView.subviews[index * 2];
    labelLeft.scale = scaleLeft;
    SXTitleLable *buttomLabel = self.smallScrollView.subviews[index * 2 +1];
    buttomLabel.scale = scaleLeft;
//     考虑到最后一个板块，如果右边已经没有板块了 就不在下面赋值scale了
    if (rightIndex < self.smallScrollView.subviews.count / 2) {
        SXTitleLable *sxTitle = self.smallScrollView.subviews[index * 2 + 2];
        sxTitle.scale = scaleRight;
        SXTitleLable *sxTitleLine = self.smallScrollView.subviews[index * 2 +3];
        sxTitleLine.scale = scaleRight;
    }
}

@end
