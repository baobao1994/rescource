//
//  NSString+Addition.m
//  TigerLottery
//
//  Created by Legolas on 14/12/9.
//  Copyright (c) 2014年 adcocoa. All rights reserved.
//

#import "NSString+Addition.h"

@implementation NSString (Addition)

- (CGSize)adaptSizeWithFont:(UIFont *)font {
    CGSize size;
    if ([self respondsToSelector:@selector(sizeWithAttributes:)]) {
        size = [self sizeWithAttributes:@{NSFontAttributeName : font}];
    }else {
        size = [self sizeWithFont:font];
    }
    return size;
}

- (CGSize)adaptSizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size {
    CGSize adaptSize;
    if ([self respondsToSelector:@selector(sizeWithAttributes:)]) {
        adaptSize = [self boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : font} context:nil].size;
    }else {
        adaptSize = [self sizeWithFont:font constrainedToSize:size lineBreakMode:NSLineBreakByWordWrapping];
    }
    return adaptSize;
}

@end
