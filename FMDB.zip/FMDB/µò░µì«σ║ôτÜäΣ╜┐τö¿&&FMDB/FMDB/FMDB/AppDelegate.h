//
//  AppDelegate.h
//  FMDB
//
//  Created by 廖日辉 on 16/3/29.
//  Copyright © 2016年 廖日辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

