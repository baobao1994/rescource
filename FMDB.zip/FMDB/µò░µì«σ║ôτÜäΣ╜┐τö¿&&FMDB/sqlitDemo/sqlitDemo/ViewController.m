//
//  ViewController.m
//  sqlitDemo
//
//  Created by rongfzh on 12-6-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

#define DBNAME    @"personinfo.sqlite"
#define ID        @"id"
#define NAME      @"name"
#define AGE       @"age"
#define ADDRESS   @"address"
#define TABLENAME @"PERSONINFO"

@interface ViewController ()

@end

@implementation ViewController


- (void)loadView{
    [super loadView];
    
    
    UIButton *openDBBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    CGRect rect=CGRectMake(60, 60, 200, 50);
    openDBBtn.frame=rect;
    [openDBBtn addTarget:self action:@selector(createDB) forControlEvents:UIControlEventTouchDown];
    [openDBBtn setTitle:@"createDB" forState:UIControlStateNormal];
    [self.view addSubview:openDBBtn];
    
    
    UIButton *insterBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    CGRect rect2=CGRectMake(60, 130, 200, 50);
    insterBtn.frame=rect2;
    [insterBtn addTarget:self action:@selector(insertData) forControlEvents:UIControlEventTouchDown];
    [insterBtn setTitle:@"insert" forState:UIControlStateNormal];
    [self.view addSubview:insterBtn];
    
    
    UIButton *updateBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    CGRect rect3=CGRectMake(60, 200, 200, 50);
    updateBtn.frame=rect3;
    [updateBtn addTarget:self action:@selector(updateData) forControlEvents:UIControlEventTouchDown];
    [updateBtn setTitle:@"update" forState:UIControlStateNormal];
    [self.view addSubview:updateBtn];
    
    UIButton *deleteBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    CGRect rect4=CGRectMake(60, 270, 200, 50);
    deleteBtn.frame=rect4;
    [deleteBtn addTarget:self action:@selector(deleteData) forControlEvents:UIControlEventTouchDown];
    [deleteBtn setTitle:@"delete" forState:UIControlStateNormal];
    [self.view addSubview:deleteBtn];
    
    UIButton *selectBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    CGRect rect5=CGRectMake(60, 340, 200, 50);
    selectBtn.frame=rect5;
    [selectBtn addTarget:self action:@selector(selectData) forControlEvents:UIControlEventTouchDown];
    [selectBtn setTitle:@"select" forState:UIControlStateNormal];
    [self.view addSubview:selectBtn];
}


- (void)createDB{
    //sql 语句
    NSString *sqlCreateTable =  [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS '%@' ('%@' INTEGER PRIMARY KEY AUTOINCREMENT, '%@' TEXT, '%@' INTEGER, '%@' TEXT)",TABLENAME,ID,NAME,AGE,ADDRESS];
    [self execSql:sqlCreateTable];
}

-(void) insertData{
    NSString *insertSql1= [NSString stringWithFormat:
                      @"INSERT INTO '%@' ('%@', '%@', '%@') VALUES ('%@', '%@', '%@')",
                      TABLENAME, NAME, AGE, ADDRESS, @"张三", @"13", @"济南"];
    [self execSql:insertSql1];
    
    NSString *insertSql2 = [NSString stringWithFormat:
                      @"INSERT INTO '%@' ('%@', '%@', '%@') VALUES ('%@', '%@', '%@')",
                      TABLENAME, NAME, AGE, ADDRESS, @"李四", @"12", @"济南"];
    [self execSql:insertSql2];
    
}

-(void) updateData{
    NSString *updateSql = [NSString stringWithFormat:
                      @"UPDATE %@ SET %@ = '%@' WHERE %@ = '%@'",
                      TABLENAME,   AGE,  @"16" ,AGE,  @"13"];
    [self execSql:updateSql];
}

-(void) deleteData{
    NSString *sdeleteSql = [NSString stringWithFormat:
                      @"delete from %@ where %@ = '%@'",
                      TABLENAME, NAME, @"张三"];
    [self execSql:sdeleteSql];
}

-(void) selectData{

    [self openDB];
    NSString *sqlQuery = [NSString stringWithFormat:
                      @"SELECT * FROM %@",TABLENAME];
    sqlite3_stmt * statement;
    
    if (sqlite3_prepare_v2(db, [sqlQuery UTF8String], -1, &statement, nil) == SQLITE_OK) {
        
        //查询结果集中一条一条的遍历所有的记录，这里的数字对应的是列值,注意这里的列值

        while (sqlite3_step(statement) == SQLITE_ROW) {
            char *name = (char*)sqlite3_column_text(statement, 1);
            NSString *nsNameStr = [[NSString alloc]initWithUTF8String:name];
            
            int age = sqlite3_column_int(statement, 2);
            
            char *address = (char*)sqlite3_column_text(statement, 3);
            NSString *nsAddressStr = [[NSString alloc]initWithUTF8String:address];
            
            NSLog(@"name:%@  age:%d  address:%@",nsNameStr,age, nsAddressStr);
        }
    }else{
        NSLog(@"select error:%@",sqlQuery);

    }
    sqlite3_close(db);
}



-(BOOL) openDB{
   //获取数据库路径
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documents = [paths objectAtIndex:0];
    NSString *database_path = [documents stringByAppendingPathComponent:DBNAME];
    
    //如果数据库存在，则用sqlite3_open直接打开（不要担心，如果数据库不存在sqlite3_open会自动创建）
    //打开数据库，这里的[path UTF8String]是将NSString转换为C字符串，因为SQLite3是采用可移植的C(而不是
    //Objective-C)编写的，它不知道什么是NSString.
    if (sqlite3_open([database_path UTF8String], &db) == SQLITE_OK) {
        return YES;
    }else{
        return NO;
        NSLog(@"数据库打开失败");
        sqlite3_close(db);
    }
}

-(void)execSql:(NSString *)sql
{    
    if ([self openDB]) {
        char *err;
        if (sqlite3_exec(db, [sql UTF8String], NULL, NULL, &err) != SQLITE_OK) {
            NSLog(@"数据库操作数据失败!");
        }else{
            NSLog(@"%@",sql);
        }
        sqlite3_close(db);
    }    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
