//
//  Test_Local_TwoTests.m
//  Test_Local_TwoTests
//
//  Created by admin on 14-8-7.
//  Copyright (c) 2014年 com.yongche. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Test_Local_TwoTests : XCTestCase

@end

@implementation Test_Local_TwoTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
