//
//  main.m
//  Test_Local_Two
//
//  Created by admin on 14-8-7.
//  Copyright (c) 2014年 com.yongche. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
