//
//  TestXIb.m
//  Test_Local_Two
//
//  Created by 唐斌 on 15/4/30.
//  Copyright (c) 2015年 com.yongche. All rights reserved.
//

#import "TestXIb.h"

@implementation TestXIb


-(void)viewDidLoad{
    [super viewDidLoad];
}



@end
