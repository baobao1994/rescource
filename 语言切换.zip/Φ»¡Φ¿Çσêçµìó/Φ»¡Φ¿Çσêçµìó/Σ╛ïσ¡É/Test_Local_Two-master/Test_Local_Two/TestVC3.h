//
//  TestVC3.h
//  Test_Local_Two
//
//  Created by admin on 14-8-8.
//  Copyright (c) 2014年 com.yongche. All rights reserved.
//


@interface TestVC3 : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *label;

@end
