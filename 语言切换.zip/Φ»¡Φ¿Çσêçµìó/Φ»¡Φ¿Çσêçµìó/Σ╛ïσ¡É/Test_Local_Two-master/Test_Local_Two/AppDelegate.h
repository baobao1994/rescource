//
//  AppDelegate.h
//  Test_Local_Two
//
//  Created by admin on 14-8-7.
//  Copyright (c) 2014年 com.yongche. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
