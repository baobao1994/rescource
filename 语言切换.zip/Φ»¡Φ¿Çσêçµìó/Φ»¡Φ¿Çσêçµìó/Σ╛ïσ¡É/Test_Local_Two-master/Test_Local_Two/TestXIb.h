//
//  TestXIb.h
//  Test_Local_Two
//
//  Created by 唐斌 on 15/4/30.
//  Copyright (c) 2015年 com.yongche. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestXIb : UIViewController

@end
