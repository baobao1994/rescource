//
//  ViewController.m
//  语言切换
//
//  Created by baobao on 15/12/29.
//  Copyright © 2015年 211206349-郭伟文. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    //4. 获取本地设备的语言
    NSUserDefaults * def = [NSUserDefaults standardUserDefaults];
    
    NSArray * arr = [def objectForKey:@"AppleLanguages"];
    
    NSString * l = [arr objectAtIndex:0];
    
    NSLog(@"languages  %@",l);
    
    //获取当前使用语言
    
    NSArray *languages = [NSLocale preferredLanguages];
    
    NSString *currentLanguage = [languages objectAtIndex:0];
    
    NSLog ( @"%@" , currentLanguage);
    
    self.lable.text = NSLocalizedString(@"string", nil);
    
    NSLog(@"====%@",NSLocalizedString(@"string", nil));
    
    
    currentLanguage = [languages objectAtIndex:1];
    
    NSLog ( @"%@" , currentLanguage);
    
    
    self.lable.text = NSLocalizedString(@"string", nil);
    
     NSLog(@"====%@",NSLocalizedString(@"string", nil));

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
