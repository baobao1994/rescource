//
//  main.m
//  语言切换
//
//  Created by baobao on 15/12/29.
//  Copyright © 2015年 211206349-郭伟文. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
