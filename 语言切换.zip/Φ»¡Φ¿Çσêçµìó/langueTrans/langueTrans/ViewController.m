//
//  ViewController.m
//  langueTrans
//
//  Created by baobao on 16/1/6.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"
#import "LanguageManager.h"
#import "AppDelegate.h"

@interface ViewController ()

@end
NSArray *data;
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    data = [LanguageManager languageStrings];
    NSLog(@"%@",data);
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)trans:(UIButton *)sender {
    [LanguageManager saveLanguageByIndex:0];
    [self reloadRootViewController];
}
- (IBAction)trans2:(UIButton *)sender {
    [LanguageManager saveLanguageByIndex:1];
    [self reloadRootViewController];
}

- (void)reloadRootViewController
{
    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    NSString *storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
    delegate.window.rootViewController = [storyboard instantiateInitialViewController];
}
@end
