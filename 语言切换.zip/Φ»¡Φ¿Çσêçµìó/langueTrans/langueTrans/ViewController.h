//
//  ViewController.h
//  langueTrans
//
//  Created by baobao on 16/1/6.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lable1;

@property (weak, nonatomic) IBOutlet UILabel *lable2;

- (IBAction)trans:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *trans;

@property (weak, nonatomic) IBOutlet UIButton *trans2;
- (IBAction)trans2:(UIButton *)sender;

@end

