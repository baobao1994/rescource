//
//  InternationalControl.h
//  app自己切换语言
//
//  Created by baobao on 15/12/29.
//  Copyright © 2015年 211206349-郭伟文. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InternationalControl : NSObject

+(NSBundle *)bundle;//获取当前资源文件

+(void)initUserLanguage;//初始化语言文件

+(NSString *)userLanguage;//获取应用当前语言

+(void)setUserlanguage:(NSString *)language;//设置当前语言

@end
