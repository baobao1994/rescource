//
//  ViewController.h
//  app自己切换语言
//
//  Created by baobao on 15/12/29.
//  Copyright © 2015年 211206349-郭伟文. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

//
//@property (nonatomic, retain) IBOutlet UILabel *inviteLabel;//lable

- (IBAction)changeLanguage:(id)sender;//点击事件

@property (retain, nonatomic) IBOutlet UIButton *btChange;//button
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *changeLanguage;
@property (weak, nonatomic) IBOutlet UILabel *inviteLabel;

@end

