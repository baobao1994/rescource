//
//  AppDelegate.h
//  app自己切换语言
//
//  Created by baobao on 15/12/29.
//  Copyright © 2015年 211206349-郭伟文. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

