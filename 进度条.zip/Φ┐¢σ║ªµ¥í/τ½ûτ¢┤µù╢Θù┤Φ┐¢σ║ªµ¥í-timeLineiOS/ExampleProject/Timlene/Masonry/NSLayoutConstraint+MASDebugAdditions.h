//
//  NSLayoutConstraint+MASDebugAdditions.h
//  Masonry
//
//  Created by Jonas Budelmann on 3/08/13.
//  Copyright (c) 2013 Jonas Budelmann. All rights reserved.
//

#import "MASUtilities.h"

/**
 *	makes debug and log output of NSLayoutConstraints more readable
 */
@interface NSLayoutConstraint (MASDebugAdditions)

@end

// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com 
