# LocalPush
本地推送demo，处理了iOS8与IOS7之前的版本

这个是本地推送的demo，处理了IOS8之后及之前的系统版本的处理，
详情说明，请参考博客：[标哥的技术博客](http://www.henishuo.com/ios-local-push-notification/)

如果有任何问题，请联系：632840804，或者huangyibiao520@163.com
在收到反馈后，会在第一时间查看并以最大的努力来为你提供帮助，谢谢！
