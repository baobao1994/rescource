//
//  AppDelegate.h
//  LocalPush
//
//  Created by mapboo on 2/17/14.
//  Copyright (c) 2014 mapboo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
