//
//  main.m
//  NotificationDemo
//
//  Created by 翁舟洋 on 15/11/3.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BRStudent.h"
#import "BRTeam.h"

int main(int argc, const char * argv[]) {
    
    
    BRTeam *forwardTeam = [BRTeam new];
    forwardTeam.name = @"IOS前锋队";
    
    BRTeam *mediumTeam = [BRTeam new];
    mediumTeam.name = @"IOS中锋队";

    
    BRStudent *mary = [BRStudent new];
    mary.name = @"mary";
    
    BRStudent *david = [BRStudent new];
    david.name = @"david";
    
    BRStudent *kate = [BRStudent new];
    kate.name = @"kate";
    
    BRStudent *lisi = [BRStudent new];
    lisi.name = @"李四";
    
    
    //通知中心，一个应用程序只有一个，无论如何运行，返回的都是一个相同的实例
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    
    //[center addObserver:mary selector:@selector(missionArrive:) name:@"编码任务" object:forwardTeam];
    //注册观察者，以便获得通知，然后做出某种回应。 下例：发送者是谁无所谓，关键是类型必须是编码任务。
    [center addObserver:mary selector:@selector(missionArrive:) name:@"编码任务" object:nil];
    //[center addObserver:david selector:@selector(missionArrive:) name:@"编码任务" object:forwardTeam];
    //发送者必须是前锋队，至于消息类型无所谓。
    [center addObserver:david selector:@selector(missionArrive:) name:nil object:forwardTeam];
    [center addObserver:kate selector:@selector(missionArrive:) name:@"发红包" object:forwardTeam];
    [center addObserver:kate selector:@selector(missionArrive:) name:@"企业作业" object:mediumTeam];
    
    //有消息都接收，无所谓谁发的，以及类型是什么。
    [center addObserver:lisi selector:@selector(missionArrive:) name:nil object:nil];
    
    
    [center postNotificationName:@"编码任务" object:forwardTeam userInfo:@{
                                                                         @"title":@"界面案不合格",
                                                                         @"detail":@"交互缺失2个"
                                                                         }];
    [center postNotificationName:@"发红包" object:forwardTeam userInfo:@{
                                                                       @"title":@"海悦迟到",
                                                                       @"detail":@"20元"
                                                                       }];
    
    [center postNotificationName:@"企业作业" object:mediumTeam userInfo:@{
                                                                      @"title":@"企业作业1",
                                                                      @"detail":@"20个交互"
                                                                      }];
    
    [center postNotificationName:@"编码任务" object:mediumTeam userInfo:@{
                                                                      @"title":@"coding1",
                                                                      @"detail":@"200个交互"
                                                                      }];
    
    
    
    
    
    return 0;
}
