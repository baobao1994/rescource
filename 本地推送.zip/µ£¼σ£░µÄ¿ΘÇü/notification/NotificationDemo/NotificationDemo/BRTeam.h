//
//  BRTeam.h
//  NotificationDemo
//
//  Created by 翁舟洋 on 15/11/3.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BRTeam : NSObject

@property (nonatomic,strong) NSString *name;

@end
