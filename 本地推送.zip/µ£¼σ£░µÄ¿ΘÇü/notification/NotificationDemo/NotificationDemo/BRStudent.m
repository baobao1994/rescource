//
//  BRStudent.m
//  NotificationDemo
//
//  Created by 翁舟洋 on 15/11/3.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "BRStudent.h"
#import "BRTeam.h"

@implementation BRStudent

- (void)missionArrive:(NSNotification *)notification{
    
    BRTeam *team = notification.object;
    
    
    NSLog(@"%@接到了%@发出的通知，通知类型：%@， 内容如下:%@", self.name, team.name, notification.name, notification.userInfo);
    
}

@end
