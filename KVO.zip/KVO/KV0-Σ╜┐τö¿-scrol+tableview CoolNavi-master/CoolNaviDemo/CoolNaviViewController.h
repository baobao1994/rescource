//
//  CoolNaviViewController.h
//  CoolNaviDemo
//
//  Created by ian on 15/9/12.
//  Copyright (c) 2015年 ian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoolNaviViewController : UIViewController

@end
