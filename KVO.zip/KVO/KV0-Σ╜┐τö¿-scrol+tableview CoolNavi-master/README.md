# CoolNavi [![star this repo](http://github-svg-buttons.herokuapp.com/star.svg?user=ianisme&repo=CoolNavi&style=flat&background=1081C1)](https://github.com/ianisme/CoolNavi) [![fork this repo](http://github-svg-buttons.herokuapp.com/fork.svg?user=ianisme&repo=CoolNavi&style=flat&background=1081C1)](https://github.com/ianisme/CoolNavi/fork)

### 说明：
- 简单实现一个炫酷的个人中心界面

### 功能如下：

- 1.上下移动头像可以缩小放大
- 2.用户头像可以点击

### 效果演示：
<img src="https://raw.githubusercontent.com/ianisme/CoolNavi/master/Demo.gif"  alt="效果展示by ian" height="568" width="320" />
### Swift版：
https://github.com/ianisme/CoolNaviDemo_Swift