//
//  Model.h
//  LHModelToJSON
//
//  Created by 3wchina01 on 16/3/23.
//  Copyright © 2016年 3wchina01. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property (nonatomic,strong) NSString* name;
@property (nonatomic,assign) int age;
@property (nonatomic,strong) NSNumber* height;
@property (nonatomic,strong) NSArray* array;
@property (nonatomic,strong) NSDictionary* dic;
@property (nonatomic,strong) NSURL* url;
@property (nonatomic,strong) NSDate* date;
@property (nonatomic,strong) NSData* data;
@property (nonatomic,assign) char c;

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com