# JNdefine 1.0 史上最全宏定义 中英双语 iOS definition DEFINE

#If you like it, please star it. If u dont like please tell us.
#如果喜欢或者帮助了您，请点星星，有建议也请知无不言，star it，谢谢。

//----------------------INSTALLATION 安装方法----------------------------

//Added the prefix header file to PROJECT:

//1.Creat a new PCH files and named it with "PrefixHeader.pch"(default name or anything you want) .

//2.Click next and go to Build Settings search Prefix Header.

//3.Double click the blank address and put this address: $(SRCROOT)/$(PROJECT_NAME)/PrefixHeader.pch

//THEN YOU CAN USE THIS IN EVERY FILES IN THIS PROJECT. Good luck.

//如何安装:

//1.创建新pch文件,默认名字即可: "PrefixHeader.pch".

//2.点击下一步再去Build Settings 搜索Prefix Header.

//3.找到Prefix Header并且双击,输入$(SRCROOT)/$(PROJECT_NAME)/PrefixHeader.pch

//现在你可以在项目内任何文件调用宏定义了,祝一切顺利.
