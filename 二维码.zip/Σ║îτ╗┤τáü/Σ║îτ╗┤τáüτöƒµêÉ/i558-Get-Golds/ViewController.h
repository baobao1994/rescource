//
//  ViewController.h
//  i558-Get-Golds
//
//  Created by baobao on 16/2/18.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

