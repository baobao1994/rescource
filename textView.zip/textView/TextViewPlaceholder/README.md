TextViewPlaceholder
===================

自定义TextView,可根据内容来 是否显示 Placeholder,可自定义Placeholder的文字颜色、大小.
