# RJTextView
Text view with font size automatically adjustment according to its frame size.

RJTextView can magnify the text's font size as you increase the textview's frame size. Otherwise, when you reduce the frame size, the font size also shrink to make the text fit inside the text view. In addition, the text font size changes in response to adding or deleting texts.

Please feel free to improve it, send comments or suggestions. Please let me know if you have great idea on it. You can contact me through Email: xiaojun.jin@outlook.com or Skype: xiaojun.jin
