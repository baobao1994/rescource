//
//  AppDelegate.h
//  dispatch_group线程组
//
//  Created by baobao on 16/3/25.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

