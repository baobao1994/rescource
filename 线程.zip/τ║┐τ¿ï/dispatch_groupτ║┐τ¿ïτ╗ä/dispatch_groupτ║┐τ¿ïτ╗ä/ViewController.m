//
//  ViewController.m
//  dispatch_group线程组
//
//  Created by baobao on 16/3/25.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    //开启一个自定义GCD队列
//    dispatch_queue_t dispatchQueue = dispatch_queue_create("queue.main", DISPATCH_QUEUE_CONCURRENT);
//    //开启一个GCD组队列
//    dispatch_group_t dispatchGroup = dispatch_group_create();
//    //异步进行
//    dispatch_group_async(dispatchGroup, dispatchQueue, ^{
//        NSLog(@"1111");
//    });
//    dispatch_group_async(dispatchGroup, dispatchQueue, ^{
//        NSLog(@"2222");
//    });
//    //执行完上面的线程操作以后回到main队列上执行一个操作
//    dispatch_group_notify(dispatchGroup, dispatch_get_main_queue(), ^{
//        NSLog(@"end");
//    });
    //同步进行->按顺序进行
    dispatch_queue_t dispatchQueue1 = dispatch_queue_create("queue1.main", DISPATCH_QUEUE_CONCURRENT);
    dispatch_queue_t dispatchQueue2 = dispatch_queue_create("queue2.main", DISPATCH_QUEUE_CONCURRENT);
    dispatch_sync(dispatchQueue1, ^{
        NSLog(@"1111");
    });
    dispatch_sync(dispatchQueue2, ^{
        NSLog(@"2222");
    });
//    dispatch_noti
//    dispatch_sync(dispatchQueue2, ^{
//        NSLog(@"2222");
//    });
//    dispatch_gr
    
}
@end
