//
//  ViewController.m
//  NSRunLoop阻塞NSOperation线程
//
//  Created by baobao on 16/3/29.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController{
    BOOL end;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"start new thread...");
    [NSThread detachNewThreadSelector:@selector(runOnNewThread) toTarget:self withObject:nil];
    while (!end) {
        NSLog(@"runLoop...");
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
        NSLog(@"runLoop end");
    }
    NSLog(@"ok");
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)runOnNewThread{
    NSLog(@"RUN FOR NEW THREAD ...");
    sleep(2);
    [self performSelectorOnMainThread:@selector(setEnd) withObject:nil waitUntilDone:NO];
//    end = YES;
    NSLog(@"END");
}
//造成while循环后语句延缓执行的原因是，runloop未被唤醒。
//因为，改变变量的值，runloop对象根本不知道。
//延缓的时长总是不定的，这是因为，有其他事件在某个时点唤醒了主线程，这才结束了while循环。
//那么，向主线程发送消息，将唤醒runloop，因此问题就解决了。
/*
 何时使用RunLoop？
 
 1.使用ports或自定义输入源 与其他线程通讯
 
 2.在线程中使用定时器
 
 3.在程序中使用performSelector等方法
 
 4.让线程周期性执行某个任务
 */
-(void)setEnd{
    end = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
