//
//  ViewController.m
//  test
//
//  Created by 郭伟文 on 16/9/8.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "ViewController.h"
#import "hederTableViewCell.h"
#import "bodyTableViewCell.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

#pragma mark - UITableView Datasource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return 200;
    } else {
        return 150 + 100 *indexPath.row;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}

//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
//    return 10;
//}
//
//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
//    return 0.1f;
//}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
//    UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 10)];
//    footView.backgroundColor = [UIColor colorWithRed:236/255.0f green:236/255.0f blue:236/255.0f alpha:1];
//    return footView;
//}
//
//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 1)];
//    headView.backgroundColor = [UIColor colorWithRed:236/255.0f green:236/255.0f blue:236/255.0f alpha:1];
//    return headView;
//}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *headerTableViewCellIdentifier = @"headerTableViewCell";
    static NSString *bodyTableViewCellIdentifier = @"bodyTableView";
    if (indexPath.row == 0) {
        hederTableViewCell *headerCell = (hederTableViewCell *)[tableView dequeueReusableCellWithIdentifier:headerTableViewCellIdentifier];
        if (headerCell == nil) {
            headerCell = [[hederTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:headerTableViewCellIdentifier];
        }
        return headerCell;
    } else {
        bodyTableViewCell *bodyCell = (bodyTableViewCell *)[tableView dequeueReusableCellWithIdentifier:bodyTableViewCellIdentifier];
        if (bodyCell == nil) {
            bodyCell = [[bodyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:bodyTableViewCellIdentifier];
        }
        return bodyCell;
    }
}

@end
