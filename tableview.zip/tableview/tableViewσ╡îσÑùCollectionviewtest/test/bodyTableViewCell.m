//
//  bodyTableViewCell.m
//  test
//
//  Created by 郭伟文 on 16/9/8.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "bodyTableViewCell.h"
#import "bodyCollectionViewCell.h"
#import "headerCollectionViewCell.h"

static NSString *bodyCollectionViewCelIdentifier = @"bodyCollectionViewCel";

@implementation bodyTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:@"bodyTableViewCell" owner:self options:nil] lastObject];
        [self setUp];
    }
    return self;
}

- (void)setUp {
    UICollectionViewFlowLayout *lotteryLayout = [[UICollectionViewFlowLayout alloc] init];
    lotteryLayout.headerReferenceSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 50);//头部的大小
    lotteryLayout.itemSize = CGSizeMake(([UIScreen mainScreen].bounds.size.width - 30 )/3, 100);//item的大小
//    lotteryLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;//滚动方向 默认向下滑动
    lotteryLayout.sectionInset = UIEdgeInsetsMake(0, 5, 0, 5);//间距
    lotteryLayout.minimumLineSpacing = 10;//上下cell的距离
    lotteryLayout.minimumInteritemSpacing = 1;
    self.collectionView.collectionViewLayout = lotteryLayout;
    self.collectionView.backgroundColor = [UIColor blueColor];
    self.collectionView.showsVerticalScrollIndicator = YES;
    self.collectionView.showsHorizontalScrollIndicator = YES;
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.collectionView registerNib:[UINib nibWithNibName:@"bodyCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:bodyCollectionViewCelIdentifier];
    [self.collectionView registerClass:[headerCollectionViewCell class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerViewHeader"];
    [self.collectionView reloadData];
}

#pragma -mark CollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 2;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

// 设置section头视图的参考大小，与tableheaderview类似
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout
referenceSizeForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        return CGSizeMake([UIScreen mainScreen].bounds.size.width, 50);
    }
    else {
        return CGSizeMake(0, 0);
    }
}

//- collectionview

- (UICollectionReusableView *) collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    UICollectionReusableView * res = nil;

    if ([kind isEqualToString: UICollectionElementKindSectionHeader]) {
        headerCollectionViewCell *headView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerViewHeader" forIndexPath:indexPath];
//        headView.backgroundColor = [UIColor redColor];
        res = headView;
    }
    
    return res;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    bodyCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:bodyCollectionViewCelIdentifier forIndexPath:indexPath];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"index.row = %ld , index.section = %ld",indexPath.row,indexPath.section);
}

@end
