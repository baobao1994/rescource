//
//  bodyCollectionViewCell.m
//  test
//
//  Created by 郭伟文 on 16/9/8.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "bodyCollectionViewCell.h"

@implementation bodyCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
