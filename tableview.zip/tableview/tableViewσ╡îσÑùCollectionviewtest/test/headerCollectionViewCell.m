//
//  headerCollectionViewCell.m
//  test
//
//  Created by 郭伟文 on 16/9/8.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "headerCollectionViewCell.h"

@implementation headerCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:@"headerCollectionViewCell" owner:self options:nil]firstObject];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
