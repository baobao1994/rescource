//
//  ViewController.m
//  i301
//
//  Created by 赵万玲 on 15/11/13.
//  Copyright © 2015年 Odalyn. All rights reserved.
//
#define CellCount 8
#define ExpandCount 4

#import "ViewController.h"
#import "OtherViewController.h"
#import "AppDelegate.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate,UIAlertViewDelegate>{
    UIButton *btnn;
    NSArray *uuu;
    UISwitch *switchview1;
    UISwitch *switchview2;
    UISwitch *switchview3;
    UISwitch *switchview4;
    BOOL isSelect1;
    BOOL isSelect2;
    BOOL isSelect3;
    BOOL isSelect4;
    
#pragma mark 验收器 第一步：账号
    //【1】选择两个账号，一个在工具箱登录，一个是本程序APP登录用的。test1-test100000 10万个都可以选。避免与别人在用的冲突
    //    T_ACCOUNT 是本程序APP用的，T_ACCOUNT 是工具箱登录用的。工具箱登录后可以观察APP发送的数据，也可以给APP发送数据
    //    APP 发送的数据叫做“输入” 调用这里定义的 input 函数，输入可以是用户输入，界面操作，按键按下等
    //{"login_name":"test0018", "display_name":"test0098", "login_passwd":1}
#define T_ACCOUNT @"test0018"
#define I_ACCOUNT @"test0088"
    /*
     {"obj":"associate","act":"mock","to_login_name":"test5986","data":{"obj":"test","act":"output1","data":"hehe"}}
     // http://www.madao168.com/dev/qMRUqc7mbpatAeXUWEE6Supkt98.html 模拟器的地址
     */

}
@property (weak, nonatomic) IBOutlet UIButton *button3;//拨打人工客服
@property (weak, nonatomic) IBOutlet UIButton *editionUpdata;
@property (weak, nonatomic) IBOutlet UISwitch *swith;
@property (weak, nonatomic) IBOutlet UIImageView *setImage;
@property (assign, nonatomic) BOOL isExpand;
@property (strong, nonatomic) NSIndexPath *selectedIndexPath;

- (IBAction)clean:(UIButton *)sender;
- (IBAction)notification:(id *)sender;
- (IBAction)callPhone:(UIButton *)sender;
- (IBAction)leave:(id)sender;
- (IBAction)isEditionUpdata:(id)sender;
- (IBAction)outAccoutNum:(id)sender;

@end

@implementation ViewController

@synthesize list = _list;
CGFloat width;
CGFloat height;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
#pragma mark 验收器 第二步：初始化环境
    //【2】初始化环境，AppDelegate.m 里面还有些SDK初始化代码
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(conn_state_changed)
                                                 name:globalConn.stateChangedNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(response_received)
                                                 name:globalConn.responseReceivedNotification object:nil];
    

    
    //定义数据源是谁
    _listview.dataSource=self;
    //并且需要设置代理（Alert的代理，在创建的时候直接指定为self即可）
    _listview.delegate=self;
    height = [UIScreen mainScreen].bounds.size.height;
    //每行高度
//    self.listview.rowHeight = height/3;
//    _listview.rowHeight = 80;
    btnn = [[UIButton alloc]initWithFrame:CGRectMake(0, 10, 20, 20)];
    NSArray *nnn = [[NSBundle mainBundle] loadNibNamed:@"jobApplicantSetView" owner:self options:nil];
    uuu = [NSArray array];
    uuu = nnn;
    self.isExpand = NO;
    switchview1 = [[UISwitch alloc] initWithFrame:CGRectZero];
    switchview2 = [[UISwitch alloc] initWithFrame:CGRectZero];
    switchview3 = [[UISwitch alloc] initWithFrame:CGRectZero];
    switchview4 = [[UISwitch alloc] initWithFrame:CGRectZero];
    isSelect1 = NO;
    isSelect2 = NO;
    isSelect3 = NO;
    isSelect4 = NO;
    switchview1.on = YES;
    switchview2.on = YES;
    switchview3.on = YES;
    switchview4.on = YES;

//
}

//将新添加的内容放在这里
- (NSArray *)indexPathsForExpandRow:(NSInteger)row {
    NSMutableArray *indexPaths = [NSMutableArray array];
    for (int i = 1; i <= ExpandCount+1; i++) {
        NSIndexPath *idxPth = [NSIndexPath indexPathForRow:row + i inSection:0];
        [indexPaths addObject:idxPth];
    }
    return [indexPaths copy];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/////////////////////////////////////////////////////////
//把下面的代码放正在开发的界面代码，开发只要关注【1】【2】【3】【4】
#pragma mark 验收器 与服务器连接成功后
- (void)conn_state_changed {
    if (globalConn.state == LOGIN_SCREEN_ENABLED) {
        
        if (globalConn.from_state == INITIAL_LOGIN || globalConn.from_state == SESSION_LOGIN) {
            
            return;
        }
        if (globalConn.from_state == REGISTRATION) {
            
            return;
        }
        //        OUTPUT.text = @"Connected!";
        NSLog(@"Connected!");
        [globalConn credential:I_ACCOUNT withPasswd:@"1"];
        [globalConn connect];
    } else if (globalConn.state == IN_SESSION) {
        //        OUTPUT.text = @"Login OK!";
        NSLog(@"Login OK!");
    }
}

#pragma mark 验收器 第三步：接收服务器传递的数据
- (void)response_received {
    
    NSLog(@"response: %@:%@ uerr:%@",
          (NSString*)[globalConn.response objectForKey:@"obj"],
          (NSString*)[globalConn.response objectForKey:@"act"],
          (NSString*)[globalConn.response objectForKey:@"uerr"]);
    
    // 【3】 工具箱那里发送 "send input" 后，会发送数据到本APP。这个是模拟服务器 “输出”
    // 如果APP 要响应服务器的输出，像请求响应，或服务器的推送，就可以在这里定义要做的处理
    // 工具箱那里发送"send input"这个： {"obj":"associate","act":"mock","to_login_name":"test5587","data":{"obj":"test","act":"output1","data":"blah"}}
    if ([(NSString*)[globalConn.response objectForKey:@"obj"] isEqualToString:@"test"]) {
        if ([(NSString*)[globalConn.response objectForKey:@"act"] isEqualToString:@"output1"]) {
            //             服务器输出，简单的在屏幕上打印这条信息
            //                        OUTPUT.text = (NSString*)[globalConn.response objectForKey:@"data"];
            //                        _telephone.text = (NSString*)[globalConn.response objectForKey:@"data"];
            NSLog(@"%@",(NSString*)[globalConn.response objectForKey:@"data"]);
        }
    }
    
    return;
}

#pragma mark  验收器  发送数据
-(void)input:(NSMutableDictionary*)data {
    NSMutableDictionary* req = [[NSMutableDictionary alloc] init];
    
    [req setObject:@"associate" forKey:@"obj"];
    [req setObject:@"mock" forKey:@"act"];
    [req setObject:T_ACCOUNT forKey:@"to_login_name"];
    [req setObject:data forKey:@"data"];
    
    [globalConn send:req];
}

/*
 // 【4】 按键按下 是用户输入，调用这里定义的 input 函数，工具箱那边登录后可以观察到
 // 通常这里会收集一些数据，一起发送到服务器。比如一个选日期的界面，这里就应该有用选择的日期
 - (IBAction)inputAction:(id)sender {
 NSMutableDictionary* data = [[NSMutableDictionary alloc] init];
 
 [data setObject:@"test" forKey:@"obj"];
 [data setObject:@"input1" forKey:@"act"];
 [data setObject:@"click" forKey:@"data"];
 // 通常还有用户在界面输入的其他数据，一起发送好了
 [self input:data];
 }
 */

///////////////////////////////////////////


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
//设置多少行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (self.isExpand) {
        return CellCount + ExpandCount+1;
    }
    return CellCount;
    
}

//指定每一行的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.isExpand && self.selectedIndexPath.row < indexPath.row && indexPath.row <= self.selectedIndexPath.row + ExpandCount) {
        return height/8;
    }else if(self.isExpand && self.selectedIndexPath.row < indexPath.row && indexPath.row <= self.selectedIndexPath.row + ExpandCount+1){
        return 15;
    }
    else {
        return height/8;
    }
}
//设置每行的cell内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    static NSString *TableSampleIdentifier = @"TableSampleIdentifier";
//    //1、先判断tableView中有无我们需要的缓存的cell，用ID类识别
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
//                             TableSampleIdentifier];
//    //2、如果没有，就直接创建，记得给ID识别号
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc]
//                initWithStyle:UITableViewCellStyleDefault
//                reuseIdentifier:TableSampleIdentifier];
//    }
    NSString *id = [NSString stringWithFormat:@"cell%ld",indexPath.section];
    //1、先判断tableView中有无我们需要的缓存的cell，用ID类识别
    UITableViewCell *cell = [_listview dequeueReusableCellWithIdentifier:id];
    //2、如果没有，就直接创建，记得给ID识别号
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:id];
    }
    NSUInteger row = [indexPath row];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
//然后给cell赋值
    NSUInteger lastROW;
    if (self.isExpand == NO) {
        lastROW = CellCount - 1;
        if (row == 0) {
            cell = uuu[1];
        }else if (row == 1){
            cell = uuu[2];
        }else if(row == 2){
            cell = uuu[3];
        }else if (row == 3){
            cell = uuu[4];
        }else if(row == 4){
            cell = uuu[5];
        }else if(row == 5){
            cell = uuu[6];
        }else if(row == 6){
            cell = uuu[7];
        }else if(row == 7){
            cell = uuu[8];
        }
        
        }else if (self.isExpand ){
            lastROW = CellCount + ExpandCount;
            if (row == 0) {
                cell = uuu[1];
            }else if (row == 1){
                cell = uuu[2];
            }else if(row == 2 + ExpandCount + 1){
                cell = uuu[3];
            }else if (row == 3 + ExpandCount + 1){
                cell = uuu[4];
            }else if(row == 4 + ExpandCount + 1){
                cell = uuu[5];
            }else if(row == 5 + ExpandCount + 1){
                cell = uuu[6];
            }else if(row == 6 + ExpandCount + 1){
                cell = uuu[7];
            }else if(row == 7 + ExpandCount + 1){
                cell = uuu[8];
            
        }}
    //首先判定是不是点击后是扩充的
    //判定你扩充的位置是不是属于正常范围的
    //判定你扩充后的大小
    //设置扩充的内容
    if (self.isExpand && self.selectedIndexPath.row < indexPath.row && indexPath.row <= self.selectedIndexPath.row + ExpandCount) {   // Expand cell
        NSLog(@"%ld ==== %ld",(long)self.selectedIndexPath.row,indexPath.row);
        NSArray *array = [[NSArray alloc] initWithObjects:@"          新消息",@"          申请被接受",@"          关注的雇主发布新工作",@"          被评价", nil];
        self.list = array;
        if (row == ExpandCount - (self.selectedIndexPath.row + 1)) {
            cell.textLabel.text = [self.list objectAtIndex:0];
            if (isSelect1) {
                switchview1.on = NO;
            }
            cell.accessoryView = switchview1;
            cell.backgroundColor = [UIColor whiteColor];
        }else if (row == ExpandCount - (self.selectedIndexPath.row + 1)+1){
            cell.textLabel.text = [self.list objectAtIndex:1];
            if (isSelect2) {
                switchview2.on = NO;
            }
            cell.accessoryView = switchview2;
            cell.backgroundColor = [UIColor whiteColor];
        }
        else if (row == ExpandCount - (self.selectedIndexPath.row + 1)+2){
            cell.textLabel.text = [self.list objectAtIndex:2];
            if (isSelect3) {
                switchview3.on = NO;
            }
            cell.accessoryView = switchview3;
            cell.backgroundColor = [UIColor whiteColor];
        }
        else if (row == ExpandCount - (self.selectedIndexPath.row + 1)+3){
            cell.textLabel.text = [self.list objectAtIndex:3];
            if (isSelect4) {
                switchview4.on = NO;
            }
            cell.accessoryView = switchview4;
            cell.backgroundColor = [UIColor whiteColor];
        }
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.textColor = [UIColor darkGrayColor];
        
    }
    else if(self.isExpand && self.selectedIndexPath.row < indexPath.row && indexPath.row <= self.selectedIndexPath.row + ExpandCount+1){
        cell.backgroundColor = [UIColor lightGrayColor];
        cell.textLabel.text = @" ";
        
    }
//    //然后给cell赋值
//    cell.textLabel.text = [self.list objectAtIndex:row];
//    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    if (row == lastROW) {
        cell.backgroundColor = [UIColor redColor];
    }
    if (row == 1) {

        UIButton *btn = [[UIButton alloc]init];
        [btn setImage:[UIImage imageNamed:@"xiala.png"] forState:UIControlStateNormal];
        btn.frame = CGRectMake(20, 35, 30, height/50);
        [cell addSubview:btn];
        
    }
    //为5个switch建立监听
    [_swith addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    [switchview1 addTarget:self action:@selector(switchAction1:) forControlEvents:UIControlEventValueChanged];
    [switchview2 addTarget:self action:@selector(switchAction1:) forControlEvents:UIControlEventValueChanged];
    [switchview3 addTarget:self action:@selector(switchAction1:) forControlEvents:UIControlEventValueChanged];
    [switchview4 addTarget:self action:@selector(switchAction1:) forControlEvents:UIControlEventValueChanged];

    return cell;
}
#pragma mark 交互2：其中一个switch关闭，系统提醒通知的switch就改变图标
-(void)switchAction1:(id)sender{
    
    if (![switchview1 isOn]||![switchview2 isOn]||![switchview3 isOn]||![switchview4 isOn]) {
        _swith.hidden = YES;
        _setImage.hidden = NO;
        
    }else if ([switchview1 isOn] && [switchview2 isOn] && [switchview3 isOn] && [switchview4 isOn]){
        _swith.hidden = NO;
        _setImage.hidden = YES;
        
    }
    
}

#pragma mark 交互3：系统提醒通知的switch改变，其他switch随时改变
-(void)switchAction:(id)sender{

    if ([switchview1 isOn]) {
        NSLog(@"close swith1!");
    }else {
        NSLog(@"open swith1!");
    }
    if ([self.swith isOn])
    {
        [switchview1 setOn:YES animated:YES];
        [switchview2 setOn:YES animated:YES];
        [switchview3 setOn:YES animated:YES];
        [switchview4 setOn:YES animated:YES];
        
        
    }
    else
    {
        [switchview1 setOn:NO animated:YES];
        [switchview2 setOn:NO animated:YES];
        [switchview3 setOn:NO animated:YES];
        [switchview4 setOn:NO animated:YES];
        
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
#pragma mark 交互1：清除缓存
    if ([NSIndexPath indexPathForRow:0 inSection:0] == indexPath) {
        [self clean];
        
    }
#pragma mark 交互2：系统提醒通知
    if ([NSIndexPath indexPathForRow:1 inSection:0] == indexPath) {
        [self notificationF:indexPath];
    }
#pragma mark 没有下拉的情况
    if (self.isExpand == NO) {
#pragma mark 交互4：拨打人工客服
        if ([NSIndexPath indexPathForRow:2 inSection:0] == indexPath) {
            [self callTelePhone];
        }
#pragma mark 交互5：语音设置 交互6：关于Shifts APP 交互7：修改密码
        if ([NSIndexPath indexPathForRow:3 inSection:0] == indexPath || [NSIndexPath indexPathForRow:4 inSection:0] == indexPath || [NSIndexPath indexPathForRow:5 inSection:0] == indexPath) {
            [self leaveInterface];
        }
#pragma mark 交互8：版本更新
        if ([NSIndexPath indexPathForRow:6 inSection:0] == indexPath){
            [self iseditionUpdata];
        }
#pragma mark 交互9：退出账号
        if ([NSIndexPath indexPathForRow:7 inSection:0] == indexPath) {
            [self outAccount];
        }
        
    }else{
#pragma mark 有下拉的情况
#pragma mark 交互4：拨打人工客服
        if ([NSIndexPath indexPathForRow:2+5 inSection:0] == indexPath) {
            [self callTelePhone];
        }
#pragma mark 交互5：语音设置 交互6：关于Shifts APP 交互7：修改密码  点击都是直接跳转到其他页面
        if ([NSIndexPath indexPathForRow:3+(ExpandCount+1) inSection:0] == indexPath || [NSIndexPath indexPathForRow:4+(ExpandCount+1) inSection:0] == indexPath || [NSIndexPath indexPathForRow:5+(ExpandCount+1) inSection:0] == indexPath) {
            [self leaveInterface];
        }
#pragma mark 交互8：版本更新
        if ([NSIndexPath indexPathForRow:6+5 inSection:0] == indexPath){
            [self iseditionUpdata];
        }
#pragma mark 交互9：退出账号
        if ([NSIndexPath indexPathForRow:7+5 inSection:0] == indexPath) {
            [self outAccount];
        }
        
    }
    }
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==0) self.listview.alpha = 1;
    else{
        [self leaveInterface];
    }
}
//方法：
//需要跳转页面
- (void)leaveInterface{
    OtherViewController *OtherVC = [[OtherViewController alloc] initWithNibName:@"OtherView" bundle:nil];
    [self presentViewController:OtherVC animated:YES completion:nil];
}
//交互1：清除缓存
- (void)clean{
    _openImage.hidden = NO;
    _openImage.alpha = 1.0;
    self.listview.alpha = 0.2;
    [UIView animateWithDuration:3  animations:^{
        _openImage.alpha = 0.0;
        self.listview.alpha = 1;
    }];

}
//交互2：系统通知
- (void)notificationF:(NSIndexPath *)indexPath{
    if (!self.selectedIndexPath) {
        self.isExpand = YES;
        self.selectedIndexPath = indexPath;
        [self.listview beginUpdates];
        [self.listview insertRowsAtIndexPaths:[self indexPathsForExpandRow:indexPath.row] withRowAnimation:UITableViewRowAnimationTop];
        [self.listview endUpdates];
    }else {
        if (self.isExpand) {
            if (self.selectedIndexPath == indexPath) {
                self.isExpand = NO;
                [self.listview beginUpdates];
                [self.listview deleteRowsAtIndexPaths:[self indexPathsForExpandRow:indexPath.row] withRowAnimation:UITableViewRowAnimationTop];
                [self.listview endUpdates];
                self.selectedIndexPath = nil;
            } else if (self.selectedIndexPath.row < indexPath.row && indexPath.row <= self.selectedIndexPath.row + ExpandCount) {
                // Select the expand cell, do the relating dealing.
            } else {
                self.isExpand = NO;
                [self.listview beginUpdates];
                [self.listview deleteRowsAtIndexPaths:[self indexPathsForExpandRow:self.selectedIndexPath.row] withRowAnimation:UITableViewRowAnimationTop];
                [self.listview endUpdates];
                self.selectedIndexPath = nil;
            }
        }
    }
    
    [_listview reloadData];
}
//交互4：拨打人工客服
- (void)callTelePhone{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"拨打Shifts客服" message:@"拨打416-496-8899" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    
    alertView.alertViewStyle = UIAlertViewStyleDefault;
    [alertView show];
}
//交互8：版本更新
- (void)iseditionUpdata{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"最新版本" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    alertView.alertViewStyle = UIAlertViewStyleDefault;
    [alertView show];

}
//交互9：退出账号
- (void)outAccount{
    self.listview.alpha = 0.2;
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"退出当前账号？" message:nil delegate:self cancelButtonTitle:@"✖️" otherButtonTitles:@"☑️", nil];
    
    alertView.alertViewStyle = UIAlertViewStyleDefault;
    [alertView show];

}
//button点击
//交互1：清除缓存
- (IBAction)clean:(UIButton *)sender {
    [self clean];
}

- (IBAction)notification:(id *)sender {
    NSIndexPath *r = [NSIndexPath indexPathForRow:1 inSection:0];
    [self notificationF:r];
}
//交互4：拨打人工客服
- (IBAction)callPhone:(UIButton *)sender {
    [self callTelePhone];
}
//交互5：语音设置 交互6：关于Shifts APP 交互7：修改密码  点击都是直接跳转到其他页面
- (IBAction)leave:(id)sender {
    [self leaveInterface];
}
//交互8：版本更新
- (IBAction)isEditionUpdata:(id)sender {
    [self iseditionUpdata];
}

//交互9：退出账号
- (IBAction)outAccoutNum:(id)sender {
    [self outAccount];
}



@end
