//
//  OtherViewViewController.m
//  i100
//
//  Created by Yzkkk on 15/11/7.
//  Copyright © 2015年 Yzkkk. All rights reserved.
//

#import "OtherViewController.h"
#import "ViewController.h"

@interface OtherViewController ()

@end

@implementation OtherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)returnBtnClick:(UIButton *)sender {
    ViewController *jobAppVC = [[ViewController alloc] initWithNibName:@"jobApplicantSetView" bundle:nil];
    [self presentViewController:jobAppVC animated:YES completion:nil];
}
@end
