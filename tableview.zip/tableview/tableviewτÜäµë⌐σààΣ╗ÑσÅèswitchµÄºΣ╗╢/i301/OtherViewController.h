//
//  OtherViewViewController.h
//  i100
//
//  Created by Yzkkk on 15/11/7.
//  Copyright © 2015年 Yzkkk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OtherViewController : UIViewController



- (IBAction)returnBtnClick:(UIButton *)sender;



@end
