//
//  ViewController.h
//  i301
//
//  Created by 赵万玲 on 15/11/13.
//  Copyright © 2015年 Odalyn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) NSArray *list; 

@property (weak, nonatomic) IBOutlet UITableView *listview;

@property (weak, nonatomic) IBOutlet UIImageView *openImage;

//@property (weak,nonatomic) UIButton *btn;


@end

