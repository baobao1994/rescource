//
//  ViewController.m
//  多个tableview的使用
//
//  Created by baobao on 15/11/9.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
@property (weak, nonatomic) IBOutlet UISearchBar *searchbar;
@property (weak, nonatomic) IBOutlet UITableView *tab1;
@property (weak, nonatomic) IBOutlet UITableView *tab2;
@end
NSArray *ar1;//存放数据1  //存放原始数据
NSArray *ar2;//存放数据2
NSArray *dataList;//存放原始数据
NSMutableArray *showData;//展示数据

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    ar1 = @[@"1",@"33",@"444",@"5535",@"hhh"];
    ar2 = @[@"2q1",@"2d2",@"23w"];
    showData = [NSMutableArray array];
    dataList = ar1;
    
    // Do any additional setup after loading the view, typically from a nib.
}
//监听数据输入
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    NSLog(@"aaa%lu",(unsigned long)[ar1 count]);//打印进入的是哪个数组
    if (searchText != nil && searchText.length > 0) {
        showData = [NSMutableArray array];
        for (NSString *tempStr in ar1) {
            if ([tempStr rangeOfString:searchText options:NSCaseInsensitiveSearch].length>0) {
                [showData addObject:tempStr];
                NSLog(@"bbb%lu",(unsigned long)[showData count]);//打印有多少数据
            }
        }
        ar1 = showData;
        [_tab1 reloadData];
    }else{
        NSLog(@"eee");
        ar1 = [NSMutableArray arrayWithArray:dataList];
        [_tab1 reloadData];
    }
}

//点击searchbar创建一个取消按钮 ---2

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    searchBar.showsCancelButton = YES;
    for (id cc in [searchBar subviews]) {
        if ([cc isKindOfClass:[UIButton class]]) {
            UIButton *btn = (UIButton *)cc;
            [btn setTitle:@"取消" forState:UIControlStateNormal];
        }
    }
    NSLog(@"should begin");
    return YES;
}
//清空里面的内容 ---1
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    searchBar.text = @"";
    NSLog(@"did begin");
}
//点击取消按钮 关闭按钮显示
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    NSLog(@"did end");
    ar1 = dataList;
    [_tab1 reloadData];
    searchBar.showsCancelButton = NO;
}
//回车的时候响应内容
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    NSLog(@"search clicked");
}
//点击取消按钮 清空内容 ---3
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    NSLog(@"cancle clicked");
    searchBar.text = @"";
    [searchBar resignFirstResponder];
}

//返回每组多少行
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView == _tab1) {
        return 1;
    }else
        return 1;
}
//给每个cell初始化
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *ID = @"celll";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    if (tableView == _tab1) {
        if (ar1 != nil && [ar1 count]>0) {
            cell.textLabel.text = [ar1 objectAtIndex:[indexPath row]];
        }
    }else if (tableView == _tab2){
        cell.textLabel.text = [ar2 objectAtIndex:[indexPath row]];
    }
    return cell;
}
//打印有多少组
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView ==_tab1) {
        return ar1.count;
    }else
        return ar2.count;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
