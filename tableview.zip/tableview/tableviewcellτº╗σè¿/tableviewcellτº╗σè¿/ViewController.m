//
//  ViewController.m
//  tableviewcell移动
//
//  Created by baobao on 16/3/9.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITableViewDataSource,UITableViewDelegate>

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title =@"简单的表";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSMutableArray *array = [[NSMutableArray alloc] initWithObjects:@"2009-12-1",@"2009-12-2",@"2009-12-3",@"2009-12-4",@"2009-12-5",@"2009-12-6",nil];
    self.noteList = array;
}


//添加行的移动
- (IBAction)move:(UIButton *)sender {
    editState = YES;
    [self.mTableView setEditing:!self.mTableView.editing animated:YES];
}
//添加行的删除
- (IBAction)delete:(UIButton *)sender {
    editState =NO;
    [self.mTableView setEditing:!self.mTableView.editing animated:YES];
}
//返回指定分期的行数分区默认是1个
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.noteList count];
}
//
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *NoteScanIdentifier =@"NoteScanIdentifier";
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:NoteScanIdentifier];
    //这里使用NoteScanIdentifer类型的可重用单元检查一下单元是否为空(nil),如果是，就要使用前面所提到的标识符字符串来创建一个新的表视图单元。
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NoteScanIdentifier];
        cell.showsReorderControl =YES;//为行指定了标准扩展图标,只有表处于编辑时才可以显示,通过设置表视图单元的这个属性，才能启动移动控件，可以进入移动的状态。
    }
    NSUInteger row = [indexPath row];
    cell.textLabel.text = [_noteList objectAtIndex:row];
    UIImage *image = [UIImage imageNamed:@"aiside.png"];
    cell.imageView.image = image;
    return cell;
}
/*行的移动方法*/

//确认编辑类型
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(!editState)//是否处于编辑状态
        return UITableViewCellEditingStyleDelete;
    else
        return UITableViewCellEditingStyleNone;
}
//指定该行能够移动
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editState)
        return YES;
    else
        return NO;  //如果点了删除行不能移动
}
//移动方法
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    NSUInteger fromRow = [sourceIndexPath row];    //要移动的位置
    NSUInteger toRow = [destinationIndexPath row]; //移动的目的位置
    id object = [_noteList objectAtIndex:fromRow]; //存储将要被移动的位置的对象
    [_noteList removeObjectAtIndex:fromRow];       //将对象从原位置移除
    [_noteList insertObject:object atIndex:toRow]; //将对象插入到新位置
}
//删除cell方法
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger row = [indexPath row]; //获取当前行
    [self.noteList removeObjectAtIndex:row]; //在数据中删除当前对象
    [_mTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];//数组执行删除操作
}

@end

