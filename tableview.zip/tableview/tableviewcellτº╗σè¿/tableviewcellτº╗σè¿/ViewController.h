//
//  ViewController.h
//  tableviewcell移动
//
//  Created by baobao on 16/3/9.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController :UIViewController
{
    BOOL editState;
}

//@property (nonatomic,retain)NSArray *noteList;
@property (nonatomic,retain)NSMutableArray *noteList;
@property (weak, nonatomic) IBOutlet UITableView *mTableView;

//添加移动操作
- (void)noteMove;

//添加删除
- (void)noteDelete:(id)sender;
- (IBAction)move:(UIButton *)sender;
- (IBAction)delete:(UIButton *)sender;


@end

