//
//  cityGroup.m
//  cityTableView
//
//  Created by baobao on 16/3/6.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "cityGroup.h"

@implementation cityGroup

- (instancetype)initWithCarGroupDict:(NSDictionary *)dict{
    
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

@end
