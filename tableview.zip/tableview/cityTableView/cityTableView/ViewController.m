//
//  ViewController.m
//  cityTableView
//
//  Created by baobao on 16/3/6.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"
#import "cityGroup.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong) NSMutableArray *citys;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.citys = [NSMutableArray array];//初始化
    //获取文件内容
    NSArray *cityGroupArray = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"cities.plist" ofType:nil]];
    //建立一个cityGroup数组
    NSMutableArray *grpArray = [NSMutableArray array];
    for (NSDictionary *dic in cityGroupArray) {
        cityGroup *group = [[cityGroup alloc] initWithCarGroupDict:dic];
        [grpArray addObject:group];
    }
    //将这个已经封装好的东西存起来
    self.citys = grpArray;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//有多少个组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.citys.count;
}
//每组有多少个
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return ((cityGroup *)_citys[section]).cities.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    //IOS有一个VIEW缓存池，里头可以缓存很多VIEW， 你如果需要一个VIEW,直接到这里要就可以了，不需要自己建。 拿到一个被缓存的view之后，你可以赋予其模型数据。
    //由于VIEW的品种太多，所以为了进行VIEW规格的识别，我们必须给每种被缓存的VIEW规格，提供一个唯一的ID.
    
    static NSString *id = @"cityCellView";
    
    UITableViewCell *cell = [_tableView dequeueReusableCellWithIdentifier:id];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:id];
    }
    
    cityGroup *group =  _citys[indexPath.section];
    
    cell.textLabel.text = group.cities[indexPath.row];
    
    return cell;
    
}

//头部的名字
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return ((cityGroup *)_citys[section]).name;
}
//侧栏名字
- (NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    return [_citys valueForKeyPath:@"name"];
}

@end
