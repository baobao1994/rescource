//
//  AppDelegate.h
//  Demo
//
//  Created by FineexMac on 16/3/7.
//  Copyright © 2016年 iOS_LiuLiuLiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

