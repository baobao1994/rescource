//
//  YMAnnotationViewController.h
//  BaiduMapDemo
//
//  Created by 杨蒙 on 16/7/5.
//  Copyright © 2016年 hrscy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YMAnnotationViewController : UIViewController

@end
