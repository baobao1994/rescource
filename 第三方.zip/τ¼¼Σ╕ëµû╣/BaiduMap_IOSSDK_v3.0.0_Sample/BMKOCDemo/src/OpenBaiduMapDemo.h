//
//  OpenBaiduMapDemo.h
//  IphoneMapSdkDemo
//
//  Created by wzy on 15/5/6.
//  Copyright (c) 2015年 Baidu. All rights reserved.
//

#ifndef IphoneMapSdkDemo_OpenBaiduMapDemo_h
#define IphoneMapSdkDemo_OpenBaiduMapDemo_h

#import <UIKit/UIKit.h>
#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>

@interface OpenBaiduMapDemo : UITableViewController {
    NSArray *_titleArray;
}



@end

#endif
