//
//  ViewController.h
//  DragButtonDemo
//
//  Created by zhangmh on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ViewController : UIViewController

@property (strong, nonatomic) UIWindow *window;

@end
