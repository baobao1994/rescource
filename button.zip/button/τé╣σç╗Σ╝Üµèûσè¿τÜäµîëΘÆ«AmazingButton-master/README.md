AmazingButton
=============
##网易新网4.0版左侧划开栏按钮风格的按钮

    AmazingButton *button = [[AmazingButton alloc] initWithFrame:CGRectMake(85, 100, 50, 50) color:[UIColor orangeColor]     type:AmaButtonTypeUser];

*注意长宽要保持一致*

###效果图  
![pic](https://github.com/yuyedaidao/AmazingButton/blob/master/AmazingButton/IMG_0215.PNG)
