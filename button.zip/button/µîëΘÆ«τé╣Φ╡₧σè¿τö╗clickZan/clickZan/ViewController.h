//
//  ViewController.h
//  clickZan
//
//  Created by Fairy on 14-8-12.
//  Copyright (c) 2014年 xian.song. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
