//
//  btViewController.h
//  BTSimpleRippleButton
//
//  Created by Balram Tiwari on 01/06/14.
//  Copyright (c) 2014 Balram. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface btViewController : UIViewController

@end
