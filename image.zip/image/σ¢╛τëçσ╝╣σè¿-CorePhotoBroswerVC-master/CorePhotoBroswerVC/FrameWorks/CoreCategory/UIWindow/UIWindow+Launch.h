//
//  UIWindow+Launch.h
//  Wifi
//
//  Created by muxi on 14/11/19.
//  Copyright (c) 2014年 muxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Launch)


/**
 *  主window
 */
+(UIWindow *)appWindow;






























@end
