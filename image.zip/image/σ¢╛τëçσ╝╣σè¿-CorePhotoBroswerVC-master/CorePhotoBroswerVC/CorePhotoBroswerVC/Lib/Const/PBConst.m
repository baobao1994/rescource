//
//  PBConst.m
//  CorePhotoBroswerVC
//
//  Created by 冯成林 on 15/5/7.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#ifndef _PBCONST_M_
#define _PBCONST_M_


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/** 间距 */
const CGFloat PBMargin = 20.0f;

















#endif
