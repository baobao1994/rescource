//
//  ShowAndPickerViewController.h
//  GetAndSelectedAlbumImages
//
//  Created by goWhere on 15/11/23.
//  Copyright © 2015年 Bruce. All rights reserved.
//

#import <UIKit/UIKit.h>
@import Photos;

@interface MyCollectionCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *imageview ;
@property (nonatomic, assign) BOOL isChosse;

@end

typedef void(^PickerPhotosCallback) (NSMutableArray *photosAraay);

@interface IWShowAndPickerViewController : UIViewController

//  将要展示的图片数据源
@property (nonatomic, strong) PHFetchResult *photoResult;

//  传递过来参数做具体设置  ------ 如果传入的数大于9，则强制取9.如果小于1，则强制为1
- (instancetype)initWithYouWantSelectedPhtotsAmount:(NSInteger )amount;

//  回调
- (void)getSelectedPhotosBack:(PickerPhotosCallback)callback;

@property (nonatomic, copy) PickerPhotosCallback photosCallback;

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com