//
//  ViewController.m
//  GetAndSelectedAlbumImages
//
//  Created by goWhere on 15/11/17.
//  Copyright © 2015年 Bruce. All rights reserved.
//

//  获取屏幕宽高
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width

#import "ViewController.h"
#import "IWShowAndPickerViewController.h"
#import "IWUIImageWithMoreInfo.h"
#import "IWRootAlbumListViewController.h"
@import Photos;

@interface ViewController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) NSMutableArray *imagesArr;

@property (nonatomic, strong) UICollectionView *collectionview;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
}

#pragma mark - 这个方法就是单纯地调用
- (void)selectImagesFromSystemAlbums{
    IWRootAlbumListViewController *rootVC = [[IWRootAlbumListViewController alloc]init];
    __block UINavigationController *rootnavi = [[UINavigationController alloc]initWithRootViewController:rootVC];
    rootVC.navigationItem.title = @"相册";
    //  图片数量
    int selectAmount = 9;
    [rootVC getParmaterWithYouWantSelectedPhtotsAmount:selectAmount];
    IWShowAndPickerViewController *showVC = [[IWShowAndPickerViewController alloc]initWithYouWantSelectedPhtotsAmount:selectAmount];
    [rootVC.navigationController pushViewController:showVC animated:NO];
    
    [self presentViewController:rootnavi animated:YES completion:^{
        
        rootVC.photosCallback = showVC.photosCallback;
    }];

    [showVC getSelectedPhotosBack:^(NSArray *photosAraay) {
        NSLog(@"--------%@",photosAraay);
    }];
}

#pragma mark - 承上，调用结束

//  添加collectionview
- (UICollectionView *)createCollectionview{
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake(SCREEN_WIDTH / 2.0-10, SCREEN_WIDTH / 2.0-10);
    
    UICollectionView *collectionview = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 120, SCREEN_WIDTH, SCREEN_HEIGHT - 100) collectionViewLayout:layout];
    [collectionview registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"myCell"];
    collectionview.backgroundColor = [UIColor whiteColor];
    collectionview.dataSource = self;
    collectionview.delegate = self;
    [self.view addSubview:collectionview];
    
    return collectionview;
}




-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.imagesArr.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"myCell" forIndexPath:indexPath];
    UIImageView *iv = [[UIImageView alloc]initWithFrame:cell.contentView.bounds];
    iv.contentMode = UIViewContentModeScaleAspectFill;
    iv.layer.masksToBounds = YES;
    iv.image = self.imagesArr[indexPath.row];
    [cell.contentView addSubview:iv];
    return cell;
}

- (IBAction)buttonclicked:(UIButton *)sender {
    self.imagesArr  = [NSMutableArray array];
    IWRootAlbumListViewController *rootVC = [[IWRootAlbumListViewController alloc]init];
    __block UINavigationController *rootnavi = [[UINavigationController alloc]initWithRootViewController:rootVC];
    rootVC.navigationItem.title = @"相册";
    //  图片数量
    int selectAmount = 9;
    [rootVC getParmaterWithYouWantSelectedPhtotsAmount:selectAmount];
     IWShowAndPickerViewController *showVC = [[IWShowAndPickerViewController alloc]initWithYouWantSelectedPhtotsAmount:selectAmount];
    [rootVC.navigationController pushViewController:showVC animated:NO];
    
    [self presentViewController:rootnavi animated:YES completion:^{
        
        rootVC.photosCallback = showVC.photosCallback;
    }];

    
    [showVC getSelectedPhotosBack:^(NSArray *photosAraay) {
        self.imagesArr = [photosAraay mutableCopy];
        //  展示
        self.collectionview = [self createCollectionview];
        [self showImageslocation];
    }];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.collectionview removeFromSuperview];
}

//  展示
- (void)showImageslocation{
    for (int i = 0; i < self.imagesArr.count; i++) {
//        IWUIImageWithMoreInfo *image = self.imagesArr[i];
//        NSLog(@"---------SSS--------%f",image.location.coordinate.latitude);
    }

}


@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com