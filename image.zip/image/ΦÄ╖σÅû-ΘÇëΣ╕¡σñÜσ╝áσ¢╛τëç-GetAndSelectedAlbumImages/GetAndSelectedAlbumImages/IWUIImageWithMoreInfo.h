//
//  IWUIImageWithMoreInfo.h
//  GetAndSelectedAlbumImages
//
//  Created by goWhere on 15/11/24.
//  Copyright © 2015年 Bruce. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CoreLocation;

@interface IWUIImageWithMoreInfo : UIImage

//  创建日期
@property (nonatomic, strong, nullable) NSDate *creationDate;
//  修改日期
@property (nonatomic, strong, nullable) NSDate *modificationDate;
//  拍照时的经纬度
@property (nonatomic, strong, nullable) CLLocation *location;
//  自身照片
@property (nonatomic, strong, nullable) UIImage *image;


@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com