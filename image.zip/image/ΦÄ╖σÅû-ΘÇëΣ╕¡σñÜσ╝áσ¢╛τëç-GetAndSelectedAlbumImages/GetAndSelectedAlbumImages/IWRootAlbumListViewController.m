//
//  RoorAlbumListViewController.m
//  GetAndSelectedAlbumImages
//
//  Created by goWhere on 15/11/25.
//  Copyright © 2015年 Bruce. All rights reserved.
//

#import "IWRootAlbumListViewController.h"
#import "IWShowAndPickerViewController.h"
@import Photos;

typedef NS_ENUM(NSInteger,SmartAlbumsType) {
    SmartCaneraRoll = 0,
    SmartSelfies,
    SmartSlo_mo,
    SmartPanoranmas,
    SmartBursts,
    SmartHidden,
    SmartVideos,
    SmartScreenshots,
    SmartTime_lapse,
    SmartRecentlyDeleted,
    SmartRecentlyAdded,
    SmartFavorites
};


#pragma mark-     --------tableview  cell  -------
@implementation MyTableViewCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.cellImageview = [[UIImageView alloc]initWithFrame:CGRectMake(2, 2, self.frame.size.height - 4, self.frame.size.height - 4)];
        self.cellImageview.layer.masksToBounds = YES;
        self.cellImageview.layer.cornerRadius = 5;
        self.cellImageview.contentMode = UIViewContentModeScaleAspectFill;
        [self addSubview:self.cellImageview];
        
        self.cellTitleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.height + 4, 0, self.frame.size.width - self.frame.size.height, self.frame.size.height)];
        self.cellTitleLabel.font = [UIFont systemFontOfSize:15.0];
        [self addSubview:self.cellTitleLabel];
    }
    return self;
}


@end


@interface IWRootAlbumListViewController ()<UITableViewDataSource,UITableViewDelegate,PHPhotoLibraryChangeObserver>

/** 数据源 */
@property (nonatomic, strong) NSMutableArray *datesourceArray;
/** tableview */
@property (nonatomic, strong) UITableView *tableview;
/** 名字数组 */
@property (nonatomic, strong) NSArray *namesArray;

/** 选择照片张数以及照片质量 */
@property (nonatomic, assign) NSInteger selectedAmount;
@property (nonatomic, assign) NSInteger photoRatio;

@end

@implementation IWRootAlbumListViewController

//  初始化
-(void)getParmaterWithYouWantSelectedPhtotsAmount:(NSInteger)amount{
    self.selectedAmount = amount;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    //  设置名字
    self.namesArray = @[@"所有照片",@"最近添加",@"屏幕快照",@"个人收藏"];
    
    //  获取所有相册大概信息，包括所有图片，智能相册，个人收藏等
    self.datesourceArray = [self getAllAlbumInformation];
    
    //  获取到信息后，在tableview中展示出来
    self.tableview = [self createAtableViewForAllAlbums];
    
    //  右上角添加取消按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(dismissAction)];
}



- (void)dismissAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark-  获取所有相册
- (NSMutableArray *)getAllAlbumInformation{

    NSMutableArray *allSmartAlbums = [NSMutableArray array];
    //  所有图片
    PHFetchOptions *allOptions = [[PHFetchOptions alloc]init];
    //  时间排序
    allOptions.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:YES]];
    PHFetchResult *allPhotos = [PHAsset fetchAssetsWithOptions:allOptions];
    [allSmartAlbums addObject:allPhotos];
    
    
    PHFetchResult *smartAlbums = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
    
    //  智能相册---最近添加
    PHAssetCollection *collection = [smartAlbums objectAtIndex:SmartRecentlyAdded];
    PHFetchResult *recentely = [PHAsset fetchAssetsInAssetCollection:collection options:nil];
    [allSmartAlbums addObject:recentely];
    
    //  智能相册---屏幕截图
    PHAssetCollection *screenshot = [smartAlbums objectAtIndex:SmartScreenshots];
    PHFetchResult *screenshotResult = [PHAsset fetchAssetsInAssetCollection:screenshot options:nil];
    [allSmartAlbums addObject:screenshotResult];
    
    //  智能相册---个人收藏
    PHAssetCollection *favorite = [smartAlbums objectAtIndex:SmartFavorites];
    PHFetchResult *favoriteResult = [PHAsset fetchAssetsInAssetCollection:favorite options:nil];
    [allSmartAlbums addObject:favoriteResult];
    
    //  个人自定义相册
    PHFetchResult *userDeterminAlbums = [PHCollectionList fetchTopLevelUserCollectionsWithOptions:nil];
    
    NSMutableArray *allAlbums = [NSMutableArray arrayWithObjects:allSmartAlbums,userDeterminAlbums, nil];
    
    [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];
    
    return allAlbums;
}

- (void)dealloc {
    [[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
}

- (void)photoLibraryDidChange:(PHChange *)changeInstance{
    //  获取所有相册大概信息，包括所有图片，智能相册，个人收藏等
    self.datesourceArray = [self getAllAlbumInformation];
    [self.tableview reloadData];
}

#pragma mark- 添加tableview，并实现其协议方法
- (UITableView *)createAtableViewForAllAlbums{
    UITableView *tableview = [[UITableView alloc]initWithFrame:self.view.bounds];
    [tableview registerClass:[MyTableViewCell class] forCellReuseIdentifier:@"myCell"];
    tableview.dataSource = self;
    tableview.delegate = self;
    [self.view addSubview:tableview];
    return tableview;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        NSArray *arr = self.datesourceArray[section];
                return arr.count;
    }else{
        PHFetchResult *result = self.datesourceArray[section];
        return result.count;
    }
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.datesourceArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MyTableViewCell *cell = [[MyTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"myCell"];

    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if (indexPath.section == 0) {
        NSArray *array = self.datesourceArray[indexPath.section];
        PHFetchResult *result = array[indexPath.row];
        cell.cellTitleLabel.text = [NSString stringWithFormat:@"%@ (%ld)",self.namesArray[indexPath.row],(long )result.count];
        
        //  显示图片
        if (result.count > 0) {
            PHAsset *singleAsset = result.lastObject;
            [[PHImageManager defaultManager] requestImageForAsset:singleAsset targetSize:CGSizeZero contentMode:PHImageContentModeAspectFill options:nil resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
                cell.cellImageview.image = result;
            }];
        }else{
            cell.cellImageview.image = [UIImage imageNamed:@"iw_none"];
        }
        
    }else{
        
        PHFetchResult *fetchResult = self.datesourceArray[indexPath.section];
        PHAssetCollection *collection = (PHAssetCollection *)fetchResult[indexPath.row];
        PHFetchResult *singleResult = [PHAsset fetchAssetsInAssetCollection:collection options:nil];
        cell.cellTitleLabel.text = [NSString stringWithFormat:@"%@ (%ld)",collection.localizedTitle,(long )singleResult.count];
        
        if (singleResult.count > 0) {
            PHAsset *singleAsset = singleResult.lastObject;
            [[PHImageManager defaultManager] requestImageForAsset:singleAsset targetSize:CGSizeZero contentMode:PHImageContentModeAspectFill options:nil resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
                cell.cellImageview.image = result;
            }];
        }else{
            cell.cellImageview.image = [UIImage imageNamed:@"iw_none"];
        }
        
    }
    
    return  cell;
}

//  点击跳转展示
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    __block IWShowAndPickerViewController *showVC = [[IWShowAndPickerViewController alloc]initWithYouWantSelectedPhtotsAmount:self.selectedAmount];
    if (indexPath.section == 0) {
        //  全部照片
        NSArray *array = self.datesourceArray[indexPath.section];
        showVC.photoResult = array[indexPath.row];
    }else{
        
        PHFetchResult *fetchResult = self.datesourceArray[indexPath.section];
        PHAssetCollection *collection = (PHAssetCollection *)fetchResult[indexPath.row];
        PHFetchResult *sigle = [PHAsset fetchAssetsInAssetCollection:collection options:nil];
        showVC.photoResult = sigle;
    }
    [showVC getSelectedPhotosBack:^(NSMutableArray *photosAraay) {
        self.photosCallback(photosAraay);
    }];
    
    if (showVC.photoResult.count > 0) {
        [self.navigationController pushViewController:showVC animated:YES];
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50.0f;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"智能相册";
    }else{
        return @"个人自定义";
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com