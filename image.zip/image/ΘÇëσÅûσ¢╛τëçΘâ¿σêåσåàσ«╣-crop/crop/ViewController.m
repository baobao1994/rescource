//
//  ViewController.m
//  crop
//
//  Created by peter on 16/3/1.
//  Copyright © 2016年 techinone. All rights reserved.
//

#import "ViewController.h"
#import "CropImageViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *originImageView;
@property (weak, nonatomic) IBOutlet UIButton *cropButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)cropAction:(id)sender {
    CropImageViewController *cropImageViewController = [[CropImageViewController alloc] initWithOriginImage:self.originImageView.image callBack:^(UIImage *cropImage, CropImageViewController *viewController) {
        self.originImageView.image = cropImage;
        [viewController dismissViewControllerAnimated:YES completion:nil];
    }];
    cropImageViewController.fixCropSize = YES;
    [self presentViewController:cropImageViewController animated:YES completion:^{
        
    }];
}

- (IBAction)resetAction:(id)sender {
    self.originImageView.image = [UIImage imageNamed:@"bundle_2.jpg"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com