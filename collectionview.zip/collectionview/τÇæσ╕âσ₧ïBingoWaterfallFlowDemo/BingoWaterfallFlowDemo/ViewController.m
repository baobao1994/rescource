//
//  ViewController.m
//  BingoWaterfallFlowDemo
//
//  Created by Bing on 16/3/17.
//  Copyright © 2016年 Bing. All rights reserved.
//

#import "ViewController.h"
#import "BWaterflowLayout.h"
#import "BShop.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "BShopCell.h"

@interface ViewController ()<UICollectionViewDataSource,BWaterflowLayoutDelegate>
/** 所有数据*/
@property (nonatomic, strong) NSMutableArray * shops;

@property (nonatomic, strong) UICollectionView * collectionView;

@end

@implementation ViewController

static NSString * const BShopId =  @"shop";

-(NSMutableArray *)shops {
    if (!_shops) {
        _shops = [NSMutableArray array];
    }
    return _shops;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupLayout];
    
    [self setupRefresh];
    
}

- (void)setupRefresh
{
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewShops)];
    
    [self.collectionView.header beginRefreshing];
    
    self.collectionView.footer.hidden = YES;

    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreShops)];
}

- (void)loadNewShops {
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSArray *shops = [BShop objectArrayWithFilename:@"1.plist"];
        [self.shops removeAllObjects];
        [self.shops addObjectsFromArray:shops];
        
        //加载数据
        [self.collectionView reloadData];
        
        [self.collectionView.header endRefreshing];
    });
}
- (void)loadMoreShops {
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSArray *shops = [BShop objectArrayWithFilename:@"1.plist"];
        [self.shops addObjectsFromArray:shops];
        
        //加载数据
        [self.collectionView reloadData];
        
        [self.collectionView.footer endRefreshing];
    });
}

- (void)setupLayout {
    //创建布局
    BWaterflowLayout * layout = [[BWaterflowLayout alloc]init];
    
    layout.delegate = self;
    
    //创建CollectionView
    UICollectionView * collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height -10) collectionViewLayout:layout];
    collectionView.dataSource = self;
    
    collectionView.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:collectionView];
    
    [collectionView registerNib:[UINib nibWithNibName:@"BShopCell" bundle:nil] forCellWithReuseIdentifier:BShopId];
    
    self.collectionView = collectionView;
}
#pragma mark - <UICollectionViewDataSource>

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    self.collectionView.footer.hidden = self.shops.count == 0;
    
    return self.shops.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    BShopCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:BShopId forIndexPath:indexPath];
//    cell.layer.borderColor = CGColorRetain((__bridge CGColorRef _Nonnull)([UIColor redColor]));
//    cell.layer.borderWidth=0.3;
    cell.shop = self.shops[indexPath.item];
    
    return cell;
}

#pragma mark - <BWaterflowLayoutDelegate>

-(CGFloat)waterflowLayout:(BWaterflowLayout *)waterflowLayout heightForItemAtIndex:(NSUInteger)index itemWidth:(CGFloat)itemWidth {
    BShop * shop = self.shops[index];
    return itemWidth * shop.h / shop.w;
}
//瀑布流列数
- (CGFloat)columnCountInWaterflowLayout:(BWaterflowLayout *)waterflowLayout {
    return 3;
}
- (CGFloat)columnMarginInWaterflowLayout:(BWaterflowLayout *)waterflowLayout {
    return 10;

}
- (CGFloat)rowMarginInWaterflowLayout:(BWaterflowLayout *)waterflowLayout {
    return 10;

}
- (UIEdgeInsets)edgeInsetsInWaterflowLayout:(BWaterflowLayout *)waterflowLayout {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com