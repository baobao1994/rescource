//
//  HorizontalViewController.h
//  LewPhotoBrowser
//
//  Created by pljhonglu on 15/5/19.
//  Copyright (c) 2015年 pljhonglu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HorizontalViewController : UIViewController
@property (nonatomic, weak)IBOutlet UICollectionView *collectionView;

@end
