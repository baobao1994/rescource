//  CollectionViewCell.h
//  palmtrends_wxcd
//
//  Created by geimin on 14-9-30.
//  Copyright (c) 2014年 Palmtrends_wxcd. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface CollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIView  *hLine;            //横线
@property (weak, nonatomic) IBOutlet UIView  *vLine;            //竖线
@property (weak, nonatomic) IBOutlet UILabel *titleLab;         //标题
@property (weak, nonatomic) IBOutlet UILabel *timeLab;          //时间
@property (weak, nonatomic) IBOutlet UILabel *sourceLab;        //来源
@property (weak, nonatomic) IBOutlet UILabel *descriptionLab;   //描述
@property (strong, nonatomic) NSDictionary   *valuationDict;    //赋值字典
@property (weak, nonatomic) IBOutlet UIView  *contentV;         //内容View

//赋值
- (void)collectionValuationFrom:(NSDictionary *)dict andRow:(NSInteger)row;

//释放内存
-(void)releaseAction;

//已读
- (void)alreadyRead;
//未读
- (void)unRead;

@end
