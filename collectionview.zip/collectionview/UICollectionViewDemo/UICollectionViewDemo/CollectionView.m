//
//  WXInformationManager.m
//  InfiniteChengDu
//
//  Created by geimin on 14-9-19.
//  Copyright (c) 2014年 CQZM. All rights reserved.
//

#import "CollectionView.h"
#import "CollectionViewCell.h"
@interface CollectionView ()<UICollectionViewDataSource , UICollectionViewDelegate >

@property (strong, nonatomic) NSMutableArray *infoArr;      //数据列表

@end

@implementation CollectionView
static NSString * const reuseIdentifier = @"CollectionViewCell";
@synthesize infoArr      = _infoArr;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(NSString *)fetchSystemVersion
{
    return [[UIDevice currentDevice] systemVersion];
}
-(void)dealloc{
    _infoArr    = nil;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    //数据准备
    [self prepareData];
    //属性设置
    [_collectionView setPagingEnabled:YES];
    [_collectionView setDelegate:self];
    [_collectionView setDataSource:self];
    [_collectionView setShowsVerticalScrollIndicator:NO];
    [_collectionView setShowsHorizontalScrollIndicator:NO];
    [_collectionView registerNib:[UINib nibWithNibName:reuseIdentifier bundle:nil] forCellWithReuseIdentifier:reuseIdentifier];
    [_collectionView setBackgroundColor:[UIColor clearColor]];
    
}
//数据准备
-(void)prepareData{
    _infoArr = nil;
    _infoArr = [[NSMutableArray alloc] init];
    
    [NSDate new];
    for (int i = 0; i < 30; i ++) {
        NSInteger idtemp = arc4random()%10000;
        NSString *idStr = [NSString stringWithFormat:@"%d",idtemp];
        NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:idStr,@"id",@"今年13名演艺明星涉黄赌毒被抓 多因群众举报",@"title",@"按照一般定义，公众人物是指一定范围内具有重要影响，为人们所关注的这类人物。",@"description",@"30分钟前",@"adddate",@"网络",@"source", nil];
        
        [_infoArr addObject:dict];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
   return 3;
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    NSInteger sectionIndex = 3;
    if(_infoArr.count > 9){
        NSInteger allIndex = _infoArr.count/9;
        if(_infoArr.count%9 != 0){
            allIndex = allIndex + 1;
        }
        sectionIndex = allIndex * 3;
    }
    return sectionIndex;
}

- (CollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    CollectionViewCell *cell = (CollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    NSInteger index = 0;
    
    //index = indexPath.row + indexPath.section*3;
    /*排位
    行      位*3
    0   9*0+0   9*0+3   9*0+6
    1   9*0+1   9*0+4   9*0+7
    2   9*0+2   9*0+5   9*0+8
    
    3   9*1+0   9*1+3   9*1+6
    4   9*1+1   9*1+4   9*1+7
    5   9*1+2   9*1+5   9*1+8
     
    6   9*2+0   9*2+3   9*2+6
    7   9*2+1   9*2+4   9*2+7
    8   9*2+2   9*2+5   9*2+8
    */
    index  = 9*(indexPath.section/3) + ((indexPath.section%3) + indexPath.row * 3);
    NSLog(@"index=%d",index);
    
    NSDictionary *tempDict;
    if(index < _infoArr.count){
        tempDict = [_infoArr objectAtIndex:index];
        [cell collectionValuationFrom:tempDict andRow:indexPath.row];
    }
    
    return  cell;
}
//cell选择
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    CollectionViewCell *colCell = (CollectionViewCell *) [collectionView cellForItemAtIndexPath:indexPath];
    NSDictionary *dic = colCell.valuationDict;
    if(dic != nil && dic.count > 0){
        //添加已读字段
        NSString *idStr = [dic objectForKey:@"id"];
        for (int i = 0; i < _infoArr.count; i++) {
            NSDictionary *tempDict = [_infoArr objectAtIndex:i];
            if([[tempDict objectForKey:@"id"] isEqualToString:idStr]){
                NSMutableDictionary *mDict = [tempDict mutableCopy];
                [mDict setObject:@"1" forKey:@"isRead"];
                
                [_infoArr insertObject:[mDict copy] atIndex:i];
                [_infoArr removeObject:tempDict];
            }
        }
    
        //已读
        [colCell alreadyRead];
    }
    NSLog(@"查看详情CollectionViewCell");
}


@end
