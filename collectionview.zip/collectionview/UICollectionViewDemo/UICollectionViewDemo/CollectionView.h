//
//  CollectionView.h
//
//  Created by geimin on 14-9-19.
//  Copyright (c) 2014年 CQZM. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface CollectionView : UIViewController
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;  //集合视图

@end
