//
//  CollectionViewCell.m
//  palmtrends_wxcd
//
//  Created by geimin on 14-9-30.
//  Copyright (c) 2014年 Palmtrends_wxcd. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell
@synthesize valuationDict = _valuationDict;
-(void)dealloc{
    _valuationDict = nil;
}
- (void)awakeFromNib {
    // Initialization code
}
//释放内存
-(void)releaseAction{
    [_titleLab setText:nil];
    [_timeLab setText:nil];
    [_sourceLab setText:nil];
    [_descriptionLab setText:nil];
    [_hLine setHidden:YES];
    [_vLine setHidden:YES];
    _valuationDict = nil;
}
//赋值
- (void)collectionValuationFrom:(NSDictionary *)dict andRow:(NSInteger)row{
    //释放内存
    [self releaseAction];
    //未读
    [self unRead];
    if(dict != nil && dict.count > 0){
        [_hLine setHidden:NO];
        [_vLine setHidden:NO];
        _valuationDict = dict;
        //赋值
        [self valueAction];
        //cell分隔线调整
        [self divLineAction:row];
    }else{
    }
}


//cell分隔线调整
-(void)divLineAction:(NSInteger)row{
    [_hLine setHidden:NO];
    CGRect hLineRect = _vLine.frame;
    if(row == 0){
        hLineRect.origin.y = 35;
        hLineRect.size.height = 165;
        [_vLine setFrame:hLineRect];
    }else if(row == 1){
        hLineRect.origin.y = 0;
        hLineRect.size.height = 200;
        [_vLine setFrame:hLineRect];
    }else if(row == 2){
        hLineRect.origin.y = 0;
        hLineRect.size.height = 165;
        [_vLine setFrame:hLineRect];
        [_hLine setHidden:YES];
    }
}

-(NSDictionary *)selectDcitAction:(NSInteger)selectInt{
    NSMutableDictionary *selctDict = (NSMutableDictionary *)_valuationDict;
    if(selctDict != nil && selctDict.count > 0){
        //选择
        if(selectInt == 1){
            [selctDict setObject:@"1" forKey:@"select"];
        }else{
            [selctDict setObject:@"0" forKey:@"select"];
        }
    }
    return (NSDictionary *)selctDict;
}
//赋值
-(void)valueAction{
    
    
    //标题label
    [_titleLab setText:[_valuationDict objectForKey:@"title"]];
    CGRect startRect = _titleLab.frame;
    [_titleLab sizeToFit];
    CGRect contentFrame = _titleLab.frame;
    contentFrame.size.width = startRect.size.width;
    if(contentFrame.size.height > 60){
        contentFrame.size.height = 60;
    }
    [_titleLab setFrame:contentFrame];
    
    //时间
    [_timeLab setText:[_valuationDict objectForKey:@"adddate"]];
    
    //来源
    [_sourceLab setText:[_valuationDict objectForKey:@"source"]];
    
    //描述
    [_descriptionLab setText:[_valuationDict objectForKey:@"description"]];
    CGRect startRect1 = _descriptionLab.frame;
    [_descriptionLab sizeToFit];
    CGRect contentFrame1 = _descriptionLab.frame;
    contentFrame1.size.width = startRect1.size.width;
    if(contentFrame1.size.height > 40){
        contentFrame1.size.height = 36;
    }
    [_descriptionLab setFrame:contentFrame1];
    
    //已读
    NSInteger isread = [[_valuationDict objectForKey:@"isRead"] intValue];
    if(isread == 1){
        [self alreadyRead];
    }
    
    
}
//已读
- (void)alreadyRead{
    [_descriptionLab setTextColor:[UIColor colorWithRed:119/255.0 green:119/255.0 blue:119/255.0 alpha:1]];
    [_titleLab       setTextColor:[UIColor colorWithRed:119/255.0 green:119/255.0 blue:119/255.0 alpha:1]];
    [_timeLab        setTextColor:[UIColor colorWithRed:119/255.0 green:119/255.0 blue:119/255.0 alpha:1]];
    [_sourceLab      setTextColor:[UIColor colorWithRed:119/255.0 green:119/255.0 blue:119/255.0 alpha:1]];
}
//未读
- (void)unRead{
    [_titleLab       setTextColor:[UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1]];
    [_descriptionLab setTextColor:[UIColor colorWithRed:86/255.0 green:86/255.0 blue:86/255.0 alpha:1]];
    [_timeLab        setTextColor:[UIColor colorWithRed:86/255.0 green:86/255.0 blue:86/255.0 alpha:1]];
    [_sourceLab      setTextColor:[UIColor colorWithRed:86/255.0 green:86/255.0 blue:86/255.0 alpha:1]];
}


@end
