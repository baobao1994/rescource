//
//  AppDelegate.h
//  UICollectionViewDemo
//
//  Created by geimin on 14/11/27.
//  Copyright (c) 2014年 Geimin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CollectionView.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) CollectionView *collectionView;
@property (strong, nonatomic) UINavigationController *nav;
@end
