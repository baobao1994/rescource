//
//  ViewController.m
//  datepicker-demo
//
//  Created by 翁舟洋 on 15/11/11.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"
#import "BRCityPickerView.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (weak, nonatomic) IBOutlet UITextField *dateEntry;
@property (weak, nonatomic) IBOutlet UITextField *cityEntry;
- (IBAction)datePick:(UIDatePicker *)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    UIDatePicker *picker = [[UIDatePicker alloc] init];
    picker.datePickerMode = UIDatePickerModeDate;
    picker.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    [picker addTarget:self action:@selector(datePickKeyBoard:) forControlEvents:UIControlEventValueChanged];
    
    
    self.dateEntry.inputView = picker;
    
    
    BRCityPickerView *cityPickView = [BRCityPickerView cityPickView];
    self.cityEntry.inputView = cityPickView;
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)datePick:(UIDatePicker *)sender {
    
    NSDate *select  = [self.datePicker date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *date = [dateFormatter stringFromDate:select];
    
    self.dateEntry.text = date;
    
}


- (IBAction)datePickKeyBoard:(UIDatePicker *)sender {
    
    NSDate *select  = [sender date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *date = [dateFormatter stringFromDate:select];
    
    self.dateEntry.text = date;
    
}
@end
