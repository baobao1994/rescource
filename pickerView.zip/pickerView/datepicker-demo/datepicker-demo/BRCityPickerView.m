//
//  BRCityPickerView.m
//  datepicker-demo
//
//  Created by 翁舟洋 on 15/11/11.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "BRCityPickerView.h"
#import "BRProvince.h"

@interface BRCityPickerView () <UIPickerViewDataSource,UIPickerViewDelegate>

@property (nonatomic,strong) NSArray *provinces;

@end

@implementation BRCityPickerView

+ (instancetype)cityPickView{
    
    return [[[NSBundle mainBundle] loadNibNamed:@"BRCityPickerView" owner:nil options:nil] lastObject];
    
}


- (NSArray *)provinces{
    
    if (_provinces == nil) {
        
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"cities.plist" ofType:nil]];
        
        NSMutableArray *provinceArray = [NSMutableArray array];
        
        for (NSDictionary *dict in dictArray) {
            BRProvince *province = [[BRProvince alloc] initWithDict:dict];
            [provinceArray addObject:province];
        }
        
        _provinces = provinceArray;
    }

    return _provinces;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2;
}


- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    if (component == 0) {
        return self.provinces.count;
    }
    else{
        NSInteger idx = [pickerView selectedRowInComponent:0];//获得选中的省的序号
        BRProvince *p = self.provinces[idx];
        return p.cities.count;
    }
    
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    if (component == 0) {
        BRProvince *province = self.provinces[row];
        return province.name;
    }
    else{
        
        NSInteger idx = [pickerView selectedRowInComponent:0];
        BRProvince *province = self.provinces[idx];
        
        return province.cities[row];
        
    }
    
    
}



@end
