//
//  BRProvince.m
//  datepicker-demo
//
//  Created by 翁舟洋 on 15/11/11.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "BRProvince.h"

@implementation BRProvince

- (instancetype)initWithDict:(NSDictionary *)dict{
    
    if (self = [super init]) {
        self.name = dict[@"name"];
        self.cities = dict[@"cities"];
    }
    
    return self;
    
}

@end
