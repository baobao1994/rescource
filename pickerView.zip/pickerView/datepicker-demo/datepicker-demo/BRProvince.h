//
//  BRProvince.h
//  datepicker-demo
//
//  Created by 翁舟洋 on 15/11/11.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BRProvince : NSObject

@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSArray *cities;

-(instancetype)initWithDict:(NSDictionary *)dict;

@end
