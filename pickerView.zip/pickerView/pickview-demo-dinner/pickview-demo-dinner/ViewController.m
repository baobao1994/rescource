//
//  ViewController.m
//  pickview-demo-dinner
//
//  Created by 翁舟洋 on 15/11/7.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic,strong) NSArray *foods;
@property (weak, nonatomic) IBOutlet UILabel *fruitLabel;
@property (weak, nonatomic) IBOutlet UILabel *mainLabel;
@property (weak, nonatomic) IBOutlet UILabel *drinkLabel;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;

@end

@implementation ViewController

//该方法就是foods属性的get方法，通过self.foods就会调用这个方法
- (NSArray *)foods{
   
    if (_foods == nil) {
        _foods = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"foods.plist" ofType:nil]];
    }
    
    return _foods;
    
}

//生成随机实物组合
- (IBAction)genRandomFoodCollection:(UIButton *)sender {
    
    for (int component = 0 ; component < self.foods.count; component++) {
         //获得每一列的食物品种数量
        int count = (int)[self.foods[component] count];
        int row = arc4random_uniform(count);
        
        [self.pickerView selectRow:row inComponent:component animated:YES];
        [self pickerView:self.pickerView didSelectRow:row inComponent:component];
        
    }
    
}

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    for (int component = 0 ; component < self.foods.count; component++) {
        [self pickerView:_pickerView didSelectRow:0 inComponent:component];
    }
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


///////////////////////////////////  UIPickView DataSource 方法 ////////////////////////////
//返回这个PICKVIEW的列的数量 (component)
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return self.foods.count;
}

//返回的PICKVIEW每个列（component）有多少行（row)
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return ((NSArray *)self.foods[component]).count;
    
}

///////////////////////////////////  UIPickView DataSource 方法 ////////////////////////////


///////////////////////////////////  UIPickView Deleget 方法 ////////////////////////////
//每行列上的文字
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return  self.foods[component][row];
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    //NSLog(@"you select %ld component, %ld row!",component,row);
    
    if (component == 0) {
        _fruitLabel.text = self.foods[component][row];
    }
    else if (component == 1) {
        _mainLabel.text = self.foods[component][row];
    }
    else if (component == 2) {
        _drinkLabel.text = self.foods[component][row];
    }
    
}




@end
