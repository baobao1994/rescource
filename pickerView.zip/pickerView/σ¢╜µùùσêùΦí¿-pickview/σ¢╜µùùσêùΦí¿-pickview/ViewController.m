//
//  ViewController.m
//  国旗列表-pickview
//
//  Created by 翁舟洋 on 15/11/7.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"
#import "BRFlag.h"
#import "BRFlagView.h"

@interface ViewController () <UIPickerViewDataSource,UIPickerViewDelegate>

@property (nonatomic,strong) NSArray *flags;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSArray *)flags{
    
    if (_flags == nil) {
       
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"flags.plist" ofType:nil]];
        
        NSMutableArray *flagArray = [NSMutableArray array];
        for (NSDictionary *dict in dictArray) {
            [flagArray addObject:[BRFlag flagWithDict:dict]];
        }
        
        _flags = flagArray;
        
    }
    
    return _flags;
    
}

//有几个pickview
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
//有多少行
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return self.flags.count;
}

//- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
//    return   ((BRFlag *)self.flags[row]).name;
//}

//加载pickview
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    //修改控件的大小只能用CGRect来改变，不能直接改变其中的宽度和高度，因为这些都是只读的
    BRFlagView *flagView = [BRFlagView flagView];
    CGRect tempFrame = flagView.frame;
    tempFrame.size.width = [[UIScreen mainScreen] bounds].size.width;
    flagView.frame = tempFrame;
    flagView.flag = self.flags[row];
    
    return flagView;
    
}
//每行的高度
-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 44;
}


@end
