//
//  BRFlagView.m
//  国旗列表-pickview
//
//  Created by 翁舟洋 on 15/11/7.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "BRFlagView.h"
#import "BRFlag.h"

@interface BRFlagView ()

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconView;

@end

@implementation BRFlagView

+ (instancetype)flagView{
    return [[[NSBundle mainBundle] loadNibNamed:@"BRFlagView" owner:nil options:nil] lastObject];
}


-(void)setFlag:(BRFlag *)flag{
  
    _flag = flag;
    
    self.nameLabel.text = flag.name;
    self.iconView.image = [UIImage imageNamed:flag.icon];
  
}

@end
