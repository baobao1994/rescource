//
//  BRFlag.m
//  国旗列表-pickview
//
//  Created by 翁舟洋 on 15/11/7.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "BRFlag.h"

@implementation BRFlag

+(instancetype)flagWithDict:(NSDictionary *)dict{
    return [[self alloc] initWithDict:dict];
}

-(BRFlag *)initWithDict:(NSDictionary *)dict{
    
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict]; //KVC
    }
    
    return self;
}

@end
