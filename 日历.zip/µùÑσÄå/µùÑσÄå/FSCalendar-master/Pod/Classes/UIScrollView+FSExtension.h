//
//  UIScrollView+FSExtension.h
//  Pods
//
//  Created by Wenchao Ding on 5/3/15.
//
//

#import <UIKit/UIKit.h>

@interface UIScrollView (FSExtension)

- (void)fs_scrollBy:(CGPoint)offset animate:(BOOL)animate;

@end
