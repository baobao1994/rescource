//
//  AppDelegate.h
//  CYLunarCalendar
//
//  Created by Cyrus on 14-5-23.
//  Copyright (c) 2014年 cyrusleung. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
