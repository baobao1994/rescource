//
//  MainViewController.h
//  CYLunarCalendar
//
//  Created by Cyrus on 14-5-23.
//  Copyright (c) 2014年 cyrusleung. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VRGCalendarView.h"

@interface MainViewController : UIViewController<VRGCalendarViewDelegate>

@end
