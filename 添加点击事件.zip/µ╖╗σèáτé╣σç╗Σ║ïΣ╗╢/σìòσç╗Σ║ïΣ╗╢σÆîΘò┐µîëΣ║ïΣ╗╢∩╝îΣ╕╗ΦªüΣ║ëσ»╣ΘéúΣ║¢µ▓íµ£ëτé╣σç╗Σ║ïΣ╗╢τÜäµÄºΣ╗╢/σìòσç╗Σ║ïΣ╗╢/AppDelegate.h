//
//  AppDelegate.h
//  单击事件
//
//  Created by JaDee on 15/11/29.
//  Copyright © 2015年 J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

