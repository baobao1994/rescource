//
//  ViewController.m
//  单击事件
//
//  Created by JaDee on 15/11/29.
//  Copyright © 2015年 J. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIGestureRecognizerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *testLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(click:)];
    self.testLabel.userInteractionEnabled = YES;//添加可以点击的动作。就是为了感应
    [self.testLabel addGestureRecognizer:tap];
    UILongPressGestureRecognizer *longPressCR1 = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPress:)];
    longPressCR1.minimumPressDuration = 1;//长按多久才会响应
    [self.testLabel addGestureRecognizer:longPressCR1];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)click:(UITapGestureRecognizer *)sender{
    NSLog(@" sadasda");
}
- (void)longPress:(UITapGestureRecognizer *)sender{
    NSLog(@"长按");
}
@end
