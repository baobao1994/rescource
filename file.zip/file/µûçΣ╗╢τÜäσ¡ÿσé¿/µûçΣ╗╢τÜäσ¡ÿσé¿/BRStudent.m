//
//  BRStudent.m
//  文件的存储
//
//  Created by baobao on 15/11/23.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import "BRStudent.h"

@implementation BRStudent

//指明了这个对象中的各个属性该如何进行存储
-(void)encodeWithCoder:(NSCoder *)encoder{
    //指明2点：
    // 1. 哪些属性需要存储    2. 用什么key来关联存储
    [encoder encodeObject:self.stuNo forKey:@"stuno"];
    [encoder encodeInteger:self.stuAge forKey:@"stuage"];
    [encoder encodeFloat:self.stuHeight forKey:@"stuheight"];
    
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    //一旦用了initWithxxx的时候，一定要用下面这句if语句
    if (self = [super init]) {
        //解码 de开头
        self.stuNo =  [aDecoder decodeObjectForKey:@"stuno"];
        self.stuAge = (int)[aDecoder decodeIntegerForKey:@"stuage"];
        self.stuHeight = [aDecoder decodeFloatForKey:@"stuheight"];
    }
    return self;
}

@end
