//
//  ViewController.m
//  文件的存储
//
//  Created by baobao on 15/11/23.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import "ViewController.h"
#import "BRStudent.h"
@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *needSave;
- (IBAction)SaveBtn:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UITextField *needGet;
- (IBAction)GetBtn:(UIButton *)sender;



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)SaveBtn:(UIButton *)sender {
   //1.这个是通用型的获取文件目录，不用担心以后document会不会改名字等因素
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *path = [doc stringByAppendingPathComponent:@"stu.data"];
    //2.终于找到这种可以存储自己所创建的对象了
    BRStudent *stu = [BRStudent new];
    stu.stuNo = @"stu001";
    stu.stuAge = 12;
    stu.stuHeight = 165.5;
    //进行编码存储。这个过程会自动调用自己定义类里面的编码，所以一定要告诉他怎么存进去，存的是什么东西
    [NSKeyedArchiver archiveRootObject:stu toFile:path];
}
- (IBAction)GetBtn:(UIButton *)sender {
    //1.获取文件位置
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"stu.data"];
    //2.进行反编码。un开头
    BRStudent *stu = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
    NSLog(@"%@ - %d - %f",stu.stuNo, stu.stuAge, stu.stuHeight);
}
@end
//preferences存储，也是无法存储自己的对象
/*
 - (IBAction)SaveBtn:(UIButton *)sender {
 
 //preferences也是一个XML存储，相对简单，文件无需定位，名字也不用管
 //1.利用NSUserDefaults就能够直接访问软件的偏好设置（library/preferences）
 NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
 //2.写数据
 [defaults setObject:_needSave.text forKey:@"test"];
 [defaults setInteger:100 forKey:@"money"];
 [defaults setBool:NO forKey:@"nomoney"];
 [defaults setFloat:12.3 forKey:@"height"];
 [defaults setObject:@"mary" forKey:@"name"];
 //3.同步数据
 [defaults synchronize];
 
 }
 - (IBAction)GetBtn:(UIButton *)sender {
 
 NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
 //根据你存入的类型进行对应的解析
 NSString *test = [defaults objectForKey:@"name"];
 NSUInteger money = [defaults integerForKey:@"money"];
 BOOL havemoney = [defaults boolForKey:@"nomoney"];
 float height = [defaults floatForKey:@"height"];
 NSLog(@"%@-%d-%ld-%f",test,havemoney,money,height);
 _needGet.text = [defaults objectForKey:@"test"];
 
 }
 */


//pilst存储
/*
 - (IBAction)SaveBtn:(UIButton *)sender {
 //1. 获得本应用程序的沙盒根路径
 NSString *home =  NSHomeDirectory();
 //NSLog(@"%@",home);
 //2.将该沙盒路径下的Documents文件夹里面存放你要存储的东西
 NSString *docPath = [home stringByAppendingString:@"/Documents"];
 //3.一定要是oc对象，不能是自己的对象，否者无法存进去
 //    NSArray *data = @[@"brsc",@"dfjdkfjdfdf",[NSNumber numberWithInt:10],@20];
 NSArray *data = @[_needSave.text];
 //4.Documents里面名字为data.plist的文件
 NSString *filePath = [docPath stringByAppendingPathComponent:@"data.plist"];
 //NSLog(@"%@",filePath);
 //5.立即刷新存储进去,一定要是数组，如果是字符串会报错
 [data writeToFile:filePath atomically:YES];
 
 }
 - (IBAction)GetBtn:(UIButton *)sender {
 
 NSString *home = NSHomeDirectory();
 
 NSString *filePath =  [home stringByAppendingPathComponent:@"Documents/data.plist"];
 
 NSArray *data = [NSArray arrayWithContentsOfFile:filePath];
 _needGet.text = data[0];
 
 NSLog(@"%@",data);
 }
 */



