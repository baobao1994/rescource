//
//  BRStudent.h
//  ArchiverFileIO-Demo
//
//  Created by 翁舟洋 on 15/11/22.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BRStudent : NSObject <NSCoding>

@property (nonatomic,strong) NSString *stuNo;
@property (nonatomic,assign) int stuAge;
@property (nonatomic,assign) float stuHeight;

@end
