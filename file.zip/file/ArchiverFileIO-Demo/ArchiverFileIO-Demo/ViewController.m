//
//  ViewController.m
//  ArchiverFileIO-Demo
//
//  Created by 翁舟洋 on 15/11/22.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"
#import "BRStudent.h"

@interface ViewController ()
- (IBAction)saveData:(UIButton *)sender;
- (IBAction)readData:(UIButton *)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)saveData:(UIButton *)sender {
    
   NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
   //NSLog(@"%@",doc);
    
   NSString *path = [doc stringByAppendingPathComponent:@"stu.data"];
   
    BRStudent *stu = [BRStudent new];
    stu.stuNo = @"stu001";
    stu.stuAge = 12;
    stu.stuHeight = 165.5;
    
    [NSKeyedArchiver archiveRootObject:stu toFile:path];
   
    
    
}

- (IBAction)readData:(UIButton *)sender {
    
   NSString *path = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"stu.data"];
    
   BRStudent *stu = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
    
    NSLog(@"%@ - %d - %f",stu.stuNo, stu.stuAge, stu.stuHeight);
    
}
@end
