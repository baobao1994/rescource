//
//  BRStudent.m
//  ArchiverFileIO-Demo
//
//  Created by 翁舟洋 on 15/11/22.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "BRStudent.h"

@implementation BRStudent

//指明了这个对象中的各个属性该如何进行存储
-(void)encodeWithCoder:(NSCoder *)encoder{
    
    //指明2点：
    // 1. 哪些属性需要存储    2. 用什么key来关联存储
    [encoder encodeObject:self.stuNo forKey:@"stuno"];
    [encoder encodeInteger:self.stuAge forKey:@"stuage"];
    //[encoder encodeFloat:self.stuHeight forKey:@"stuheight"];
    
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    
    if (self = [super init]) {
        
       self.stuNo =  [aDecoder decodeObjectForKey:@"stuno"];
       self.stuAge = [aDecoder decodeIntegerForKey:@"stuage"];
       self.stuHeight = [aDecoder decodeFloatForKey:@"stuheight"];
        
    }
    
    return self;
    
    
}


@end
