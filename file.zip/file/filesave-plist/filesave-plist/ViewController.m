//
//  ViewController.m
//  filesave-plist
//
//  Created by 翁舟洋 on 15/11/21.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//file

#import "ViewController.h"
#import "BRStudent.h"

@interface ViewController ()
- (IBAction)readData:(UIButton *)sender;
- (IBAction)saveData:(UIButton *)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)readData:(UIButton *)sender {
    
    NSString *home = NSHomeDirectory();
    
    NSString *filePath =  [home stringByAppendingPathComponent:@"Documents/data.plist"];
    
    //NSLog(@"%@",filePath);
    
    NSArray *data = [NSArray arrayWithContentsOfFile:filePath];
    NSLog(@"%@",data);
    
    
}

- (IBAction)saveData:(UIButton *)sender {
    
    BRStudent *stu = [[BRStudent alloc] init];
    
    //1. 获得本应用程序的沙盒根路径
    NSString *home =  NSHomeDirectory();
    //NSLog(@"%@",home);
    NSString *docPath = [home stringByAppendingString:@"/Documents"];
    
    NSArray *data = @[@"brsc",@"dfjdkfjdfdf",[NSNumber numberWithInt:10],@20];
    
    NSString *filePath = [docPath stringByAppendingPathComponent:@"data.plist"];
    
    //NSLog(@"%@",filePath);
    
    [data writeToFile:filePath atomically:YES];
    

    
}
@end
