//
//  main.m
//  url转换
//
//  Created by baobao on 15/12/22.
//  Copyright © 2015年 211206349-郭伟文. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        
        NSString *image = @"http://112.124.70.60:8081/cgi-bin/download.pl?fid=f14478312488823580741003&proj=demo";
        NSLog(@"%@",image);
        NSData *dd = [NSData dataWithContentsOfFile:image];
        NSLog(@"%@",dd);
        
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"fileName" ofType:@"png"];
        NSLog(@"%@",filePath);
        NSData *image1 = [NSData dataWithContentsOfFile:filePath];
        NSLog(@"%@",image1);
//        UIImage *image = [UIImage imageWithData:image];
//        NSURL *imageURLa = [NSURL URLWithString:@"http://112.124.70.60:8081/cgi-bin/download.pl?fid=f14478312488823580741003&proj=demo"];
//        NSData *data = [NSData dataWithContentsOfURL:imageURLa];
//        NSData *dd = [NSData data]
//        NSLog(@"====%@",data);
    }
    return 0;
}
