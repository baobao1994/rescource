//
//  ViewController.m
//  液晶数字字体
//
//  Created by 郭伟文 on 16/4/28.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "ViewController.h"
/*
 第一步先下载好字体文本--http://font.niutuku.com/tools/down.php?caid=3&id=21833
 第二步点击文本控件进行添加
 第三步选择你安装好的字体
 */

@interface ViewController ()
//@property (strong,nonatomic) __block dispatch_semaphore_t sem;
@end

@implementation ViewController

//- (void) textNextBlock: (void(^)()) result {
//    for (int i = 0; i <3; i++) {
//        NSLog(@"123");
//    }
//    sleep(1);
//     dispatch_semaphore_signal(_sem);
//}


- (void)viewDidLoad {
    [super viewDidLoad];
//    _sem = dispatch_semaphore_create(0);
//    dispatch_semaphore_signal(_sem);
//    for (__block int i = 0; i <3; i++) {
//        dispatch_semaphore_wait(_sem, DISPATCH_TIME_FOREVER);
//        [self textNextBlock:^{
//            NSLog(@"%d",i);
//        }];
//    }

//    dispatch_group_t group = dispatch_group_create();
//    dispatch_group_async(group, dispatch_get_global_queue(0,0), ^{
//        // 并行执行的线程一
//        for (int i = 0; i < 3; i++) {
//            NSLog(@"01 -- %@",[NSThread currentThread]);
//        }
//    });
//    dispatch_group_async(group, dispatch_get_global_queue(0,0), ^{
//        // 并行执行的线程二
//        for (int i = 0; i < 4; i++) {
//            NSLog(@"02 -- %@",[NSThread currentThread]);
//        }
//    });
//    dispatch_group_notify(group, dispatch_get_global_queue(0,0), ^{
//        // 汇总结果
//        for (int i = 0; i < 2; i++) {
//            NSLog(@"03 -- %@",[NSThread currentThread]);
//        }
//    });
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
