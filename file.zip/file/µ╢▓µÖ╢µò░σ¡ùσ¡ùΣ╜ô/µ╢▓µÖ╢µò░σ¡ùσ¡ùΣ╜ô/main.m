//
//  main.m
//  液晶数字字体
//
//  Created by 郭伟文 on 16/4/28.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
