//
//  ViewController.m
//  normal-files
//
//  Created by 翁舟洋 on 15/11/4.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"

extern void calc(int a, int b);

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    calc(1,2);
    
    BRLog(@"this is a book! a = %d",10);
    
    //self.view.backgroundColor = [UIColor redColor];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
