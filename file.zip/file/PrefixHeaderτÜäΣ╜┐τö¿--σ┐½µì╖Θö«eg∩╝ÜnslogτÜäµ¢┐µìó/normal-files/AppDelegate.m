//
//  AppDelegate.m
//  normal-files
//
//  Created by 翁舟洋 on 15/11/4.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
     BRLog(@"app 结束启动了，可以工作了");
    
    UIApplication *app1 = [UIApplication sharedApplication];
    UIApplication *app2 = [UIApplication sharedApplication];
    //UIApplication *app3 = [[UIApplication alloc] init]; //只能由一个UIApplication的实例，不能再有新的实例了。
    
    //BRLog(@"%p,%p,%p",app1,app2,app3);
    [UIApplication sharedApplication].applicationIconBadgeNumber = 20;
    app1.networkActivityIndicatorVisible = YES;
    
    //通过UIApplication对象可以打开其它程序
    //[app1 openURL: [NSURL URLWithString:@"http://www.sina.com"]];
    //[app1 openURL: [NSURL URLWithString:@"tel://133783784949"]];
//    [app1 openURL: [NSURL URLWithString:@"sms://133783784949"]];
//    [app1 openURL: [NSURL URLWithString:@"mailto://133783784949"]];
    
    //app1.statusBarHidden = NO;
    //app1.statusBarStyle = UIStatusBarStyleLightContent;
    
    [app1 setStatusBarHidden:YES animated:UIStatusBarAnimationSlide];
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    int a = xyz;
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    BRLog(@"goto backkground");
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    BRLog(@"goto foreground");
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
         BRLog(@"app 要结束工作了，有话要说吗？");
}

@end
