//
//  ViewController.m
//  保存图片到沙盒
//
//  Created by baobao on 16/3/29.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>

@interface ViewController ()<UIImagePickerControllerDelegate,UIActionSheetDelegate,UIApplicationDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *images;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)get:(UIButton *)sender {
    NSString *paths = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *filePath = [paths stringByAppendingPathComponent:[NSString stringWithFormat:@"112.png"]];
    self.images.image = [UIImage imageWithContentsOfFile:filePath];
}

- (IBAction)clike:(UIButton *)sender {
    UIActionSheet *action;
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        action = [[UIActionSheet alloc] initWithTitle:@"获取图片" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"从相册选择",nil];
    }else
    {
        action = [[UIActionSheet alloc] initWithTitle:@"获取图片" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:@"从相册选择",nil];
    }
    [action showInView:self.view];
}
#pragma mark - 调用UIActionSheet iOS7使用
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSUInteger sourceType = 0;
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        switch (buttonIndex) {
            case 0:
                sourceType = UIImagePickerControllerSourceTypeCamera;
                break;
            case 1:
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                break;
            default:
                return;
        }
    }
    else{
        if (buttonIndex == 0) {
            sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        }
    }
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc]init];
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = YES;
    imagePickerController.sourceType = sourceType;
    [self presentViewController:imagePickerController animated:YES completion:nil];
}
#pragma mark - 确定图片并获取图片名字-尤其是图片3的名字
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    NSURL *imageURL = [info valueForKey:UIImagePickerControllerReferenceURL];
    ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
    {
        ALAssetRepresentation *representation = [myasset defaultRepresentation];
        NSString *fileName = [representation filename];
        NSLog(@"fileName : %@",fileName);
    };
    ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
    [assetslibrary assetForURL:imageURL
                   resultBlock:resultblock
                  failureBlock:nil];
    [self performSelector:@selector(saveImage:) withObject:image afterDelay:0.5];
    [picker dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark -取消图片
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark -保存图像
static int change1,change2,change3,change4,change5;
- (void)saveImage:(UIImage *)image{
    //这个步骤就是将图片写入到沙盒中，名字可以自己定
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [path firstObject];
    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"offersPhoto.jpg"];
    [UIImageJPEGRepresentation(image, 1.0f) writeToFile:imagePath atomically:YES];
    
    UIImage *portrait = [UIImage imageWithContentsOfFile:imagePath];
    self.images.image = portrait;

    NSString *paths = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *filePath = [paths stringByAppendingPathComponent:[NSString stringWithFormat:@"112.png"]];
    NSLog(@"%@",paths);
    [UIImagePNGRepresentation(portrait) writeToFile:filePath atomically:YES];
//    NSMutableDictionary *info = [NSMutableDictionary dictionary];
    
    //弹出提示框
//    NSString *title = NSLocalizedString(@"上传商标", nil);
//    NSString *message = NSLocalizedString(@"上传该图片作为公司的商标吗？", nil);
//    if (p1 == 20) {
//        title = NSLocalizedString(@"上传头像", nil);
//        message = NSLocalizedString(@"上传该图片作为您的头像吗？", nil);
//    }else if (p1 >=30 && p1<= 32){
//        title = NSLocalizedString(@"上传图片", nil);
//        message = NSLocalizedString(@"上传该图片作为您的图库吗？", nil);
//    }
//    NSString *cancelButtonTitle = NSLocalizedString(@"取消", nil);
//    NSString *otherButtonTitle = NSLocalizedString(@"确定", nil);
//    
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
//    
//    // Create the actions.
//    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
//        if (p1 == 10) {//商标
//            if (change1 == 0) {
//                [_imageBTN setBackgroundImage:imageTubiao forState:UIControlStateNormal];
//            }else
//                [_imageBTN setBackgroundImage:imageTubiao2 forState:UIControlStateNormal];
//        }else if(p1 == 20){//头像
//            if (change2 == 0) {
//                [_TouxianBTN setBackgroundImage:imageTouxiang forState:UIControlStateNormal];
//            }else
//                [_TouxianBTN setBackgroundImage:imageTouxiang2 forState:UIControlStateNormal];
//        }else if(p1 == 30){//最后的图片
//            if (change3 == 0) {//如果改变了
//                [_Picture3 setBackgroundImage:image3 forState:UIControlStateNormal];
//            }else
//                [_Picture3 setBackgroundImage:image4 forState:UIControlStateNormal];
//        }else if(p1 == 31){//最后的图片
//            if (change4 == 0) {//如果改变了
//                [_Picture1 setBackgroundImage:image1 forState:UIControlStateNormal];
//            }else
//                [_Picture1 setBackgroundImage:image5 forState:UIControlStateNormal];
//        }else if(p1 == 32){//最后的图片
//            if (change5 == 0) {//如果改变了
//                [_Picture2 setBackgroundImage:image2 forState:UIControlStateNormal];
//            }else
//                [_Picture2 setBackgroundImage:image6 forState:UIControlStateNormal];
//        }
//        
//    }];
//    
//    UIAlertAction *otherAction = [UIAlertAction actionWithTitle:otherButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
//        
//    }];
//    
//    //     Add the actions.
//    [alertController addAction:cancelAction];
//    [alertController addAction:otherAction];
//    
//    [self presentViewController:alertController animated:YES completion:nil];
}

@end
