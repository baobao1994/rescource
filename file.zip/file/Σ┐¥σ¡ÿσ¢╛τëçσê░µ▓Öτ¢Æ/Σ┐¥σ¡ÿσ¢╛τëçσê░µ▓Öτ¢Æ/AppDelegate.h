//
//  AppDelegate.h
//  保存图片到沙盒
//
//  Created by baobao on 16/3/29.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

