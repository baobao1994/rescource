//
//  ViewController.m
//  plist使用
//
//  Created by baobao on 16/1/5.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //转plist
    NSString *path = [[NSBundle mainBundle] pathForResource:@"music" ofType:@"txt"];
    NSString *about = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"%@",about);
    NSArray *array = [about componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    NSString *plistPath = [NSHomeDirectory() stringByAppendingString:@"weatherCityAPI.plist"];
    NSMutableArray *result = [[NSMutableArray alloc] initWithCapacity:0];
    for (NSInteger i = 0; i< array.count; i ++) {
        NSString *str = [array objectAtIndex:i];
        NSArray *arr = [str componentsSeparatedByString:@"\t"];
        [result addObject:@{@"ID":[arr objectAtIndex:0],@"City":[arr objectAtIndex:1]}];
    }
    
    
    
    
    [result writeToFile:plistPath atomically:YES];
//    NSLog(@"%@",plistPath);
    NSMutableArray *ID = [NSMutableArray array];
    NSMutableArray *City = [NSMutableArray array];
    for (NSDictionary *dic in result) {
        [ID addObject:dic[@"ID"]];
        [City addObject:dic[@"City"]];
    }
    NSLog(@"ID%@",ID);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
