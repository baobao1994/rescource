//
//  BRStudent.h
//  PreferencesWork
//
//  Created by 翁舟洋 on 15/11/22.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BRStudent : NSObject

@property (nonatomic,strong) NSString *name;

@end
