//
//  ViewController.m
//  PreferencesWork
//
//  Created by 翁舟洋 on 15/11/22.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"
#import "BRStudent.h"

@interface ViewController ()
- (IBAction)saveData:(UIButton *)sender;
- (IBAction)readData:(UIButton *)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)saveData:(UIButton *)sender {
    
    //preferences也是一个XML存储，但相对简单，文件无需定位，名字也不用管。
    
    //利用NSUserDefault就能够直接访问的软件的偏好设置（library/preferences)
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    //2.写数据
    [defaults setInteger:100 forKey:@"money"];
    [defaults setBool:NO forKey:@"haveMoney"];
    [defaults setDouble:1.73 forKey:@"height"];
    [defaults setObject:@"superstar" forKey:@"test"];
   //[defaults setObject:[BRStudent new] forKey:@"stu"];
    
    //3.同步数据，理解写盘
    [defaults synchronize];
    
}

- (IBAction)readData:(UIButton *)sender {
    
   // NSLog(@"%@",NSHomeDirectory());
    NSUserDefaults *defauls = [NSUserDefaults standardUserDefaults];
    
   NSString *test = [defauls objectForKey:@"test"];

   NSInteger money  = [defauls integerForKey:@"money"];
    
    NSLog(@" %@ - %d",test,money);
    
    
    
}
@end
