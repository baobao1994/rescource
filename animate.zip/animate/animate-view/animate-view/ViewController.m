//
//  ViewController.m
//  animate-view
//
//  Created by 翁舟洋 on 15/10/13.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)btnClick:(UIButton *)btn{
    NSLog(@"btn is clicked! %@",btn);
}

- (IBAction)createBar:(UIBarButtonItem *)sender {
    
    __block CGRect frame = CGRectMake(320, 65, 320, 50);
    UIView *view = [[UIView alloc] initWithFrame:frame];
    view.backgroundColor = [UIColor redColor];
    view.alpha=0;
    view.tag=1000;
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn setTitle:@"测试" forState:UIControlStateNormal];
    [btn setTitle:@"---" forState:UIControlStateHighlighted];
    btn.frame = CGRectMake(200, 10, 60, 32);
    btn.backgroundColor=[UIColor whiteColor];
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [view addSubview:btn];
    
    [self.view addSubview:view];
    
    [UIView animateWithDuration:3 animations:^{
        frame.origin.x = 0;
        view.frame=frame;
        view.alpha=1;
    } completion:^(BOOL finished) {
        _removeBtn.enabled = YES;
    }];
    
}

- (IBAction)removeBar:(UIBarButtonItem *)sender {
    
//    for (id obj in self.view.subviews) {
//        NSLog(@"%@",obj);
//    }
    
    UIView *lastView = self.view.subviews.lastObject;
    
    [UIView animateWithDuration:2 animations:^{
        CGRect tempFrame = lastView.frame;
        tempFrame.origin.x=320;
        lastView.frame=tempFrame;
        lastView.alpha = 0;
    } completion:^(BOOL finished) {
        [lastView removeFromSuperview];
        
        if (![self.view.subviews.lastObject isKindOfClass:[UIView class]]) {
           self.removeBtn.enabled=NO;
        }
        
        UILayoutGuide *c;
        
        
//        if (self.view.subviews.lastObject.tag!=1000) {
//            self.removeBtn.enabled=NO;
//        }
        

    }];
    
    
    
    
}

@end
