//
//  ViewController.h
//  animate-view
//
//  Created by 翁舟洋 on 15/10/13.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIBarButtonItem *removeBtn;

- (IBAction)createBar:(UIBarButtonItem *)sender;
- (IBAction)removeBar:(UIBarButtonItem *)sender;

@end

