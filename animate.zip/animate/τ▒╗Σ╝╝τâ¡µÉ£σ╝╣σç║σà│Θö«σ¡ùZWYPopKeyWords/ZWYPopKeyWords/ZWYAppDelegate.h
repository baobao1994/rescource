//
//  ZWYAppDelegate.h
//  ZWYPopKeyWords
//
//  Created by 赵纬宇 on 14-6-16.
//  Copyright (c) 2014年 ZWY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZWYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
