//
//  main.m
//  ZWYPopKeyWords
//
//  Created by 赵纬宇 on 14-6-16.
//  Copyright (c) 2014年 ZWY. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZWYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZWYAppDelegate class]));
    }
}
