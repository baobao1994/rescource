//
//  AppDelegate.h
//  LXDMaskViewAnimation
//
//  Created by 林欣达 on 16/5/10.
//  Copyright © 2016年 CNPay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

