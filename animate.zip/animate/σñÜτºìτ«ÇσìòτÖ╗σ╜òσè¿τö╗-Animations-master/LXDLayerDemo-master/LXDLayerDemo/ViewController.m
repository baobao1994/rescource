//
//  ViewController.m
//  LXDLayerDemo
//
//  Created by linxinda on 15/11/17.
//  Copyright © 2015年 sindriLin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
