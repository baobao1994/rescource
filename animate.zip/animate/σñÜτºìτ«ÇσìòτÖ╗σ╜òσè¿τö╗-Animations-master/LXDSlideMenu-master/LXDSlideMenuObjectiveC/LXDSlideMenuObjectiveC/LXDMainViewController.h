//
//  LXDMainViewController.h
//  LXDSlideMenuObjectiveC
//
//  Created by linxinda on 15/11/29.
//  Copyright © 2015年 sindriLin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LXDMainViewController : UITabBarController

@end
