//
//  OC-Swift-Bridge-Header.h
//  LXDReplicateDemo
//
//  Created by 林欣达 on 16/6/3.
//  Copyright © 2016年 CNPay. All rights reserved.
//

#ifndef OC_Swift_Bridge_Header_h
#define OC_Swift_Bridge_Header_h

#import "LXDGCD.h"

#endif /* OC_Swift_Bridge_Header_h */
