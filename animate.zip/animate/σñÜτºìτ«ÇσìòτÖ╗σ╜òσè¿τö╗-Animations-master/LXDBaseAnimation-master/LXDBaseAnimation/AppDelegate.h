//
//  AppDelegate.h
//  LXDBaseAnimation
//
//  Created by linxinda on 16/2/18.
//  Copyright © 2016年 sindriLin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

