//
//  LXDProgressView.h
//  LXDProgressView
//
//  Created by 林欣达 on 15/11/17.
//  Copyright © 2015年 sindri lin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LXDProgressLayer.h"

@interface LXDProgressView : UIView

@property (nonatomic, strong) LXDProgressLayer * progressLayer;

@end
