//
//  AppDelegate.h
//  SXWaveAnimate
//
//  Created by dongshangxian on 15/5/17.
//  Copyright (c) 2015年 Sankuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

