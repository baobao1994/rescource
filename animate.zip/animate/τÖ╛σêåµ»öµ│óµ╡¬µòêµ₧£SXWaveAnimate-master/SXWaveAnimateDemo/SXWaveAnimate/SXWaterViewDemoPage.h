//
//  SXViewController.h
//  SXWaveAnimate
//
//  Created by dongshangxian on 15/7/25.
//  Copyright (c) 2015年 Sankuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SXWaterViewDemoPage : UIViewController

@property(nonatomic,assign)CGFloat precent;

@end
