//
//  ViewController.m
//  Fly
//
//  Created by YuQian on 14-5-8.
//  Copyright (c) 2014年 zjj. All rights reserved.
//

#define k_FontSize         (arc4random() % 15) + 12
#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSArray *colorArray = @[[UIColor greenColor],[UIColor blueColor],[UIColor purpleColor],[UIColor redColor],[UIColor grayColor],[UIColor magentaColor],[UIColor brownColor]];
    NSMutableArray *titlesArray = [[NSMutableArray alloc] initWithObjects:@"灯具",@"地面",@"管材",@"石料",@"阀门",@"金属材料",@"家具",@"油漆",@"涂料", nil];
    NSMutableArray *frameArray = [[NSMutableArray alloc] initWithObjects:@"{{54, 92}, {120, 30}}",@"{{26, 228}, {120, 30}}",@"{{132, 124}, {120, 30}}",@"{{64, 146}, {120, 30}}",@"{{180, 175}, {120, 30}}",@"{{54, 190}, {120, 30}}",@"{{132, 238}, {120, 30}}",@"{{170, 269}, {120, 30}}",@"{{47, 290}, {120, 30}}", nil];
    for (UILabel *label in [self.view subviews]) {
        label.text = [titlesArray objectAtIndex:0];
        [titlesArray removeObjectAtIndex:0];
        label.textColor = colorArray[arc4random()%[colorArray count]];
        label.font = [UIFont systemFontOfSize:k_FontSize];
        label.frame = CGRectZero;
        label.center = self.view.center;
    }
    
    for (UILabel *label in [self.view subviews]) {
        [UIView animateWithDuration:2 animations:^{
            label.frame = CGRectFromString(frameArray[0]);
            [frameArray removeObjectAtIndex:0];
        } completion:nil];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
