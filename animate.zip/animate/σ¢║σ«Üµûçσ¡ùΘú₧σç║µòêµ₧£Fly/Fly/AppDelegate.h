//
//  AppDelegate.h
//  Fly
//
//  Created by YuQian on 14-5-8.
//  Copyright (c) 2014年 zjj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
