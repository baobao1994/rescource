//
//  UIImage+Category.m
//  category添加属性
//
//  Created by baobao on 16/3/22.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "UIImage+Category.h"
#import <objc/runtime.h>
//必须使用到runtime运行机制-->动态运行时

static const void *tagKey = &tagKey;

@implementation UIImage (Category)

- (NSString *)tag{
    return objc_getAssociatedObject(self, &tagKey);
}
-(void)setTag:(NSString *)tag{
    objc_setAssociatedObject(self, tagKey, tag, OBJC_ASSOCIATION_COPY_NONATOMIC);
}
@end
