//
//  UIImage+Category.h
//  category添加属性
//
//  Created by baobao on 16/3/22.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Category)
//添加的属性
@property(nonatomic,copy) NSString *tag;
//添加方法可以随便写一个

@end
