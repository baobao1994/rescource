//
//  ViewController.m
//  category添加属性
//
//  Created by baobao on 16/3/22.
//  Copyright © 2016年 baobao. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+Category.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImage *image = [[UIImage alloc] init];
    [image setTag:@"2"];
    NSLog(@"tag = %@",[image tag]);
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
