//
//  secondViewViewController.h
//  传值1
//
//  Created by baobao on 15/11/4.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface secondViewViewController : UIViewController<PassTrendValueDelegate>


@property(nonatomic,retain) __strong id<PassTrendValueDelegate> string;

@end
