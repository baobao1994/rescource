//
//  ViewController.m
//  传值1
//
//  Created by baobao on 15/11/3.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import "ViewController.h"
#import "secondViewViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *value;
- (IBAction)send:(UIButton *)sender;

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)send:(UIButton *)sender {
    secondViewViewController *val = [[secondViewViewController alloc] initWithNibName:@"secondViewViewController" bundle:nil];
    self.trendDelegate = val;
    [self.trendDelegate passTrendValues:_value.text];
    
    
    
    
    
    //    val.string = _value.text;
//    NSLog(@"111%@",val.string);
//    [self.navigationController pushViewController:val animated:YES];
    
}
@end
