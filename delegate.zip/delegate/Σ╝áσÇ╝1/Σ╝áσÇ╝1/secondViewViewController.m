//
//  secondViewViewController.m
//  传值1
//
//  Created by baobao on 15/11/4.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import "secondViewViewController.h"

@interface secondViewViewController ()

@property (strong, nonatomic) IBOutlet UITextField *value1;

@end

@implementation secondViewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    secondViewViewController *second = [secondViewViewController new];
//    second.string = @"afsdf";
//    _string = @"asdf";
//    NSLog(@"asdf%@",_string);
//    [_value1 setText:_string];
//    _value1.text = _string;
    // Do any additional setup after loading the view.
//    _value1.text = @"222";
//    NSLog(@"%@",_string);
//    [self passTrendValues:@"123"];
}
- (void)passTrendValues:(NSString *)values{
//    _value1 = [[UITextField alloc]init];
//    NSString *sss = values;
    _string = values;
    _value1.text = _string;
    NSLog(@"aaa%@",_value1.text);
    NSLog(@"values:::%@",values);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
