//
//  AppDelegate.h
//  传值1
//
//  Created by baobao on 15/11/3.
//  Copyright © 2015年 博瑞思创-S12-郭伟文-习题. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

