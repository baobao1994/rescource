//
//  ViewController.m
//  popChuanZhi
//
//  Created by 郭伟文 on 16/9/9.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "ViewController.h"
#import "BViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"index = %ld",self.index);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)pushBpageVC:(UIButton *)sender {
    [self.navigationController pushViewController:[[BViewController alloc]init] animated:YES];
}
@end
