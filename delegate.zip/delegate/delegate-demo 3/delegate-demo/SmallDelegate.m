//
//  SmallDelegate.m
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "SmallDelegate.h"

@implementation SmallDelegate

- (int)countTicket{
    return 0;
}

- (void)buyTicket{
    NSLog(@"加价100，天下最良心的价格!!!");
}

@end
