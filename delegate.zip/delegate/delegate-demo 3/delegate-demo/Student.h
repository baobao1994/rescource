//
//  Student.h
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RainWayTicketDelegate.h"
#import "TicketDelegate.h"


@interface Student : NSObject

@property (nonatomic,strong) NSString *stuName;
@property (nonatomic,assign) NSInteger *stuAge;
@property (nonatomic,strong) id<TicketDelegate> delegate;


- (instancetype)initWithDelegate:(id<TicketDelegate>)delegate;
- (void)goHome;

@end
