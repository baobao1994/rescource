//
//  RainWayTicketDelegate.m
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "RainWayTicketDelegate.h"

@implementation RainWayTicketDelegate

- (int)countTicket{
    return 10;
}

- (void)buyTicket{
    NSLog(@"去重庆这个票很难买， 加价200块，已经亏了!");
}

@end
