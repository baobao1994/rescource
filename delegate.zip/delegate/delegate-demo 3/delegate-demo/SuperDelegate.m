//
//  SuperDelegate.m
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "SuperDelegate.h"

@implementation SuperDelegate

- (int)countTicket{
    return 100;
}

- (void)buyTicket{
    NSLog(@"加价300元，我告诉你，就我这里有了，不贵！");
}

@end
