//
//  Student.m
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "Student.h"
#import "RainWayTicketDelegate.h"

@implementation Student

- (void)goHome{
    
    if ([self.delegate countTicket] >0 ) {
        [self.delegate buyTicket];
         NSLog(@"终于回去了，黄牛太多了。。。");
    }
    else
        NSLog(@"没票了，还是在学校过年吧。");
    
}

- (instancetype)initWithDelegate:(id<TicketDelegate>)delegate{
 
    if (self = [super init]) {
        self.delegate = delegate;
    }
    
    return self;

}

@end
