//
//  main.m
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
#import "TicketDelegate.h"
#import "SmallDelegate.h"
#import "SuperDelegate.h"
#import "Dog.h"

int main(int argc, const char * argv[]) {
    
    SmallDelegate *smallDelegate = [[SmallDelegate alloc] init];
    SuperDelegate *superDelegate = [[SuperDelegate alloc] init];
    
    
//    Student *stu = [[Student alloc] initWithDelegate:smallDelegate];
//    [stu goHome];
//    
//    Student *stu1 = [[Student alloc] initWithDelegate:superDelegate];
//    [stu1 goHome];
    
    Student *stu2 = [[Student alloc] initWithDelegate:[Dog new]];
    [stu2 goHome];
    
    
    return 0;
}
