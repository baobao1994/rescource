//
//  SmallDelegate.h
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TicketDelegate.h"

@interface SmallDelegate : NSObject <TicketDelegate>

@end
