//
//  Dog.m
//  delegate-demo
//
//  Created by 翁舟洋 on 15/10/18.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "Dog.h"

@implementation Dog

- (int)countTicket{
    return 1;
}

- (void)buyTicket{
    
}

@end
