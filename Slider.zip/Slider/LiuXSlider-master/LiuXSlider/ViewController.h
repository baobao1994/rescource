//
//  ViewController.h
//  LiuXSlider
//
//  Created by 刘鑫 on 16/3/24.
//  Copyright © 2016年 liuxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

