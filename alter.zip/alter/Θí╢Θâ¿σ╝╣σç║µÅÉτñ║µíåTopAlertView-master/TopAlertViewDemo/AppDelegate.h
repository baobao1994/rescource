//
//  AppDelegate.h
//  TopAlertViewDemo
//
//  Created by 陆浩志 on 15-2-13.
//  Copyright (c) 2015年 MOZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

