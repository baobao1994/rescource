//
//  AppDelegate.h
//  SGPopSelectView
//
//  Created by Sagi on 14-10-29.
//  Copyright (c) 2014年 azurelab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

