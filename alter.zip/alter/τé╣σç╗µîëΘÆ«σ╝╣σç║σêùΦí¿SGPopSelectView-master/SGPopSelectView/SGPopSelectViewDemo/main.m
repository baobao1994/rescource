//
//  main.m
//  SGPopSelectView
//
//  Created by Sagi on 14-10-29.
//  Copyright (c) 2014年 azurelab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
