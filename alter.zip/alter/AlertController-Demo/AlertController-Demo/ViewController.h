//
//  ViewController.h
//  AlertController-Demo
//
//  Created by 翁舟洋 on 15/12/17.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

