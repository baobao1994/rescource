//
//  ViewController.m
//  AlertController-Demo
//
//  Created by 翁舟洋 on 15/12/17.
//  Copyright © 2015年 福州博瑞思创教育科技有限公司 - 课堂案例. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //危险的或者具有重大意义的操作，我们一般都有弹窗提示。
    //1. UIAlertView
    
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"警告" message:@"您的系统出现了故障!" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
//    
//    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
//    [alert show];
    
    //2. UIActionSheet
//    UIActionSheet *alert = [[UIActionSheet alloc] initWithTitle:@"系统正准备删除重要文件，是否继续？" delegate:nil cancelButtonTitle:@"取消" destructiveButtonTitle:@"删除文件" otherButtonTitles:@"关闭", nil];
//    
//    [alert showInView: self.view];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"警告" message:@"准备格式化系统?" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.secureTextEntry = YES;
        textField.text = @"123";
    }];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"you click the ok button!");
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"you click the cancel button!");
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"其它" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"you click the default button!");
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
}

@end
