//
//  main.m
//  DXPopoverDemo
//
//  Created by xiekw on 11/21/14.
//  Copyright (c) 2014 xiekw. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DXAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DXAppDelegate class]));
    }
}
