//
//  DXAppDelegate.h
//  DXPopoverDemo
//
//  Created by xiekw on 11/21/14.
//  Copyright (c) 2014 xiekw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DXAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
