//
//  LXDAlphaNavController.h
//  LXDAlphaNavigationController
//
//  Created by 林欣达 on 15/10/29.
//  Copyright © 2015年 sindri lin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LXDAlphaNavController : UINavigationController

@property (nonatomic, strong) UIColor * barColor;
@property (nonatomic, assign) CGFloat barAlpha;

@end
