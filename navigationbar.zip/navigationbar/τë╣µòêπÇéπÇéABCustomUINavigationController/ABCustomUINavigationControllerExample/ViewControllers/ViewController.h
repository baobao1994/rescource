//
//  ViewController.h
//  SquaresFlipNavigationExample
//
//  Created by Andrés Brun on 7/14/13.
//  Copyright (c) 2013 Andrés Brun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (id)initViewController;

@end
