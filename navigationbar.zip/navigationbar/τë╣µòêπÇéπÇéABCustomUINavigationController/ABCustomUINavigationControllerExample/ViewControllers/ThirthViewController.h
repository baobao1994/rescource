//
//  ThirthViewController.h
//  SquaresFlipNavigationExample
//
//  Created by Andrés Brun on 7/25/13.
//  Copyright (c) 2013 Andrés Brun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirthViewController : UIViewController

- (id)initViewController;

@end
