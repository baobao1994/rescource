DGElasticPullToRefresh效果的OC版本

![image](https://github.com/wxp2012/ElasticViewAnimation/blob/master/AnimationGif.gif)

详情博客地址:http://blog.csdn.net/w_x_p/article/details/50482815

原博客地址:http://iostuts.io/2015/10/17/elastic-bounce-using-uibezierpath-and-pan-gesture/
