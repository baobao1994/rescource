//
//  UIViewController+CustomNavigationBar.m
//  NavigationCustomButtonItem
//
//  Created by 郭伟文 on 16/9/5.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "UIViewController+CustomNavigationBar.h"

#define kCustomItemWitdh(number) (number * 40)

@implementation UIViewController (CustomNavigationBar)

- (void)createCustomNavigationBarWithLeftIems:(NSArray *)leftItemsArr andRightItems:(NSArray *)rightItemsArr andTitle:(NSString *)title{
    self.title = title;
    NSInteger tagIndex = 0;
    if (leftItemsArr) {
        NSMutableArray *leftBarButtons = [[NSMutableArray alloc] init];
        for (int i = 0; i < leftItemsArr.count; i ++) {
            if ([leftItemsArr[i] isKindOfClass:[UIImage class]]) {
                [leftBarButtons addObject:[self createNavigationBarWithImage:leftItemsArr[i] index:i]];
            } else if ([leftItemsArr[i] isKindOfClass:[NSString class]]) {
                [leftBarButtons addObject:[self createNavigationBarWithTitle:leftItemsArr[i] index:i]];
            }
        }
        tagIndex = leftItemsArr.count - 1;
        self.navigationItem.leftBarButtonItems = leftBarButtons;
    }
    if (rightItemsArr) {
        tagIndex += rightItemsArr.count;
        NSMutableArray *rightBarButtons = [[NSMutableArray alloc] init];
        for (int i = 0; i < rightItemsArr.count; i ++) {
            if ([rightItemsArr[i] isKindOfClass:[UIImage class]]) {
                [rightBarButtons addObject:[self createNavigationBarWithImage:rightItemsArr[i] index:tagIndex - i]];
            } else if ([rightItemsArr[i] isKindOfClass:[NSString class]]) {
                [rightBarButtons addObject:[self createNavigationBarWithTitle:rightItemsArr[i] index:tagIndex - i]];
            }
        }
        self.navigationItem.rightBarButtonItems = rightBarButtons;
    }
}

- (void)createNavigationBackItem:(NSString *)backTitle {
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    [backBtn setImage:[UIImage imageNamed:@"arrow_left"] forState:UIControlStateNormal];
    [backBtn setTitle:backTitle forState:UIControlStateNormal];
    backBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [backBtn addTarget:self action:@selector(popViewController:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = backItem;
}

- (UIBarButtonItem *)createNavigationBarWithImage:(UIImage *)itemImage index:(NSInteger)index{
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithImage:itemImage style:UIBarButtonItemStyleDone target:self action:@selector(selectedNavigationCustomItem:)];
    barButton.tag = index;
    [barButton setTintColor:[UIColor whiteColor]];
    return barButton;
}

- (UIBarButtonItem *)createNavigationBarWithTitle:(NSString *)itemsTitle index:(NSInteger)index{
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithTitle:itemsTitle style:UIBarButtonItemStyleDone target:self action:@selector(selectedNavigationCustomItem:)];
    barButton.tag = index;
    [barButton setTintColor:[UIColor whiteColor]];
    return barButton;
}

- (void)createNavigationLeftItemWithImage:(UIImage *)image {
    self.navigationItem.leftBarButtonItem = [self createNavigationBarWithImage:image index:0];
}

- (void)createNavigationRightItemWithImage:(UIImage *)image {
    self.navigationItem.rightBarButtonItem = [self createNavigationBarWithImage:image index:1];
}

- (void)selectedNavigationCustomItem:(UIBarButtonItem *)sender {}

- (void)popViewController:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    NSInteger index = self.navigationController.viewControllers.count - 2;
    if (index >= 0) {
        UIViewController *vc = [self.navigationController.viewControllers objectAtIndex:index];
        self.navigationController.delegate = vc;
    }
}

@end
