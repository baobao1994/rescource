//
//  UIViewController+CustomNavigationBar.h
//  NavigationCustomButtonItem
//
//  Created by 郭伟文 on 16/9/5.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (CustomNavigationBar)<UINavigationControllerDelegate, UIGestureRecognizerDelegate>

- (void)createNavigationBackItem:(NSString *)backTitle;

- (void)createNavigationLeftItemWithImage:(UIImage *)image;

- (void)createNavigationRightItemWithImage:(UIImage *)image;

- (void)createCustomNavigationBarWithLeftIems:(NSArray *)leftItemsArr andRightItems:(NSArray *)rightItemsArr andTitle:(NSString *)title;

- (void)popViewController:(id)sender;

- (void)selectedNavigationCustomItem:(UIBarButtonItem *)sender;

@end
