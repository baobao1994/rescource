//
//  FirstView.m
//  NavigationCustomButtonItem
//
//  Created by 郭伟文 on 16/9/5.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "FirstView.h"
#import "FirstCollectionViewCell.h"

#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define kScreenHeight ([UIScreen mainScreen].bounds.size.height/2)

static NSString *FirstCollectionViewCellID = @"FirstCollectionViewCell";

@interface FirstView ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) UICollectionView *rankingView;

@end

@implementation FirstView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:@"FirstView" owner:self options:nil] firstObject];
        self.translatesAutoresizingMaskIntoConstraints = NO;
        [self setUp];
    }
    return self;
}

- (void)setUp {
    
    UICollectionViewFlowLayout * flowLayout= [[UICollectionViewFlowLayout alloc]init];
//    flowLayout.itemSize = CGSizeMake(kScreenWidth, kScreenHeight);
    flowLayout.sectionInset = UIEdgeInsetsZero;
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    flowLayout.minimumLineSpacing = 0;
    flowLayout.minimumInteritemSpacing = 0;
    
    _rankingView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 64, kScreenWidth, kScreenHeight) collectionViewLayout:flowLayout];
    _rankingView.collectionViewLayout = flowLayout;
    [_rankingView registerClass:[FirstCollectionViewCell class] forCellWithReuseIdentifier:FirstCollectionViewCellID];
    _rankingView.backgroundColor = [UIColor whiteColor];
    _rankingView.delegate = self;
    _rankingView.pagingEnabled = YES;
    _rankingView.dataSource = self;
//    _rankingView.scrollEnabled = NO;
    [self addSubview:_rankingView];
    
}

#pragma mark - UICollectionView Delegate

//- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
//    
//}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return [self height:indexPath.row];
}

- (CGSize)height:(NSInteger)index{
    NSLog(@"index = %ld",index);
    return CGSizeMake(kScreenWidth, kScreenHeight + index * 50);
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 5;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FirstCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:FirstCollectionViewCellID forIndexPath:indexPath];
    if (indexPath.row == 0) {
        cell.backgroundColor = [UIColor yellowColor];
    } else if (indexPath.row ==1) {
        cell.backgroundColor = [UIColor redColor];
    } else if (indexPath.row ==2) {
        cell.backgroundColor = [UIColor blueColor];
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"点击");
}


@end
