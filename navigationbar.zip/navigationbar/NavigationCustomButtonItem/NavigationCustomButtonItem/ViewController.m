//
//  ViewController.m
//  NavigationCustomButtonItem
//
//  Created by 郭伟文 on 16/9/5.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)ddd:(UIBarButtonItem *)sender {
}

- (void)press:(UIBarButtonItem *)sender {
    
}

- (void)press2:(UIBarButtonItem *)sender {
    
}

@end
