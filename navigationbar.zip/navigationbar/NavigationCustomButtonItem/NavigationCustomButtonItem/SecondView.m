//
//  SecondView.m
//  NavigationCustomButtonItem
//
//  Created by 郭伟文 on 16/9/5.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "SecondView.h"

@implementation SecondView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:@"SecondView" owner:self options:nil] firstObject];
    }
    return self;
}

@end
