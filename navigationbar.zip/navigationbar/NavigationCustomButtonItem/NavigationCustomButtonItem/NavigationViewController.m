//
//  NavigationViewController.m
//  NavigationCustomButtonItem
//
//  Created by 郭伟文 on 16/9/5.
//  Copyright © 2016年 郭伟文. All rights reserved.
//

#import "NavigationViewController.h"
#import "UIViewController+CustomNavigationBar.h"
#import "FirstView.h"
#import "SecondView.h"

@interface NavigationViewController ()

@property (nonatomic, strong) FirstView *view1;
@property (nonatomic, strong) SecondView *view2;

@end

@implementation NavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *leftBarArr = [NSArray arrayWithObjects:@"OPOP",[UIImage imageNamed:@"focus_tab_nor"], nil];
    NSArray *rightArr = [NSArray arrayWithObjects: @"ooo",[UIImage imageNamed:@"focus_tab_nor"], nil];
//    [self createCustomNavigationBarWithLeftIems:leftBarArr andRightItems:rightArr andTitle:@"oo"];
    [self createNavigationLeftItemWithImage:[UIImage imageNamed:@"focus_tab_nor"]];
    [self createNavigationRightItemWithImage:[UIImage imageNamed:@"focus_tab_nor"]];
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 80, 40)];
    titleView.backgroundColor = [UIColor redColor];
    UIButton *newBtn = [[UIButton alloc] initWithFrame:CGRectMake(1, 1, 39, 38)];
    [newBtn setBackgroundColor:[UIColor whiteColor]];
    [newBtn setTitle:@"新" forState:UIControlStateNormal];
    [newBtn setTitle:@"新" forState:UIControlStateHighlighted];
    [newBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [newBtn setTitleColor:[UIColor yellowColor] forState:UIControlStateHighlighted];
    [newBtn setTitleColor:[UIColor yellowColor] forState:UIControlStateSelected];
    [newBtn addTarget:self action:@selector(click1:) forControlEvents:UIControlEventTouchUpInside];
    [titleView addSubview:newBtn];
    self.navigationItem.titleView = titleView;
    
    
    _view1 = [[FirstView alloc] init];
    _view1.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [self.view addSubview:_view1];
    _view2 = [[SecondView alloc] init];
    _view2.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    _view2.hidden = YES;
    [self.view addSubview:_view2];
}
- (void)selectedNavigationCustomItem:(UIBarButtonItem *)sender {
    NSLog(@"%ld",sender.tag);
}

- (void)click1:(UIButton *)sender {
    NSLog(@"dddd");
    _view1.hidden = !_view1.hidden;
    _view2.hidden = !_view2.hidden;
}

@end
