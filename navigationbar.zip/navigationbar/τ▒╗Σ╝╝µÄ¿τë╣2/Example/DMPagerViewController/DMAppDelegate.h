//
//  DMAppDelegate.h
//  DMPagerViewController
//
//  Created by CocoaPods on 01/12/2015.
//  Copyright (c) 2014 Daniele Margutti. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DMPagerViewController/DMPagerViewController.h>

#import "TestViewController.h"

@interface DMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) DMPagerViewController	*pagerController;

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com